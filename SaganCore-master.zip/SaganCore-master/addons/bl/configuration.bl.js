/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

let basebl = require('sagan-dev-node-sdk').bl.base;
let BASE = new basebl('configuration');
let redis = require('../../cache');
const async = require('async');
const logger = require('../../sagan-logging/logger');

let db = BASE;

const AVATAR = "avatar";
const EXPERTISE = "expertise";
const REGISTRY = "registry";
const LINK = "link";
const MANIFEST = "manifest";
const CLIENT_KEY = "clientID";

// Cache expiry time(in seconds). Currently, same for all APIs.
const CACHE_EXPIRY = 3600;

//////////////////////
// base functions   // maybe extract this to a parent class?
//////////////////////

db.getAllClientConfiguration = function (clientID, callback) {
    let self = db;
    self.getAllByAttribute(CLIENT_KEY, clientID, function (err, results) {
        if (err) {
            logger.error('getAllClientConfiguration', clientID, null, null, "Problem fetching client's data - "+err, null, false);
             
            callback(null);
        } else {
            callback(returnOnlyData(results));
        }
    })
};

db.getAllClientConfigurationRaw = function (clientID, callback) {
    let self = db;
    self.getAllByAttribute(CLIENT_KEY, clientID, function (err, results) {
        if (err) {
            logger.error('getAllClientConfigurationRaw', clientID, null, null, "Problem fetching client's data - "+err, null, false);
             
            callback(null);
        } else {
            callback(results);
        }
    })
};

let deleteCacheData = function(cacheKey) {
    if(typeof cacheKey === 'object') {
        for(var i=0; i<cacheKey.length; i++) {
            redis.deleteKey(cacheKey[i], function(err) {
                if (err) {
                     logger.error('deleteCacheData', null, null, null, "Error deleting data from in redis: "+err, null, false);
                      
                }
                logger.error('deleteCacheData', null, null, null, "Deleting data from cache for keys: "+cacheKey, null, false);
                 
            });
        }
    } else {
        redis.deleteKey(cacheKey, function(err) {
            if (err) {
                logger.error('deleteCacheData', null, null, null, "Error deleting data from in redis: "+err, null, false);
                 
            }
            logger.error('deleteCacheData', null, null, null, "Deleting data from cache for keys: "+cacheKey, null, false);
             
        });
    }
}

let copyData = function (target, source) {
    let keys = Object.keys(source);

    keys.forEach(function (key) {
        target[key] = source[key];
    });
};

let returnOnlyData = function (oldArray) {
    let newArray = [];

    oldArray.forEach(function (item) {
        newArray.push(item.data);
    });

    return (newArray);
};

let getAllClientEntites = function (clientID, entityType, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getAllClientEntites', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            results = returnOnlyData(results);
            // add results to cache
            var resultsForCache = JSON.stringify(results);
            var cacheKey = 'core-'+clientID+'-'+entityType;
            redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(results);
        }
    });
};

let getClientEntityByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getClientEntityByKeyValueArray', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            callback(results[0]);
        }
    });
};

let getClientEntityByKeyValue = function (clientID, entityType, key, value, callback) {
    getClientEntityByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let getAllClientEntitiesByKeyValueArray = function (clientID, entityType, keyValueArray, callback) {
    let self = db;

    let query =
        {
            "params": [{
                "key": CLIENT_KEY,
                "value": clientID,
                "operand": "="
            },
                {
                    "key": "type",
                    "value": entityType,
                    "operand": "="
                }]
        };

    keyValueArray.forEach(function (pair) {
        query.params.push({
            "key": "data." + pair.key,
            "value": pair.value,
            "operand": "="
        })
    });

    self.dal.select(query, function (err, results) {
        if (err) {
            logger.error('getAllClientEntitiesByKeyValueArray', clientID, null, null, "Problem fetching client's data - " + err, null, false);
             
            callback(null);
        } else {
            callback(results);
        }
    });
};

let getAllClientEntitiesByKeyValue = function (clientID, entityType, key, value, callback) {
    getAllClientEntitiesByKeyValueArray(clientID, entityType, [{"key": key, "value": value}], callback);
};

let insertClientEntity = function (clientID, entityType, data, callback) {
    let self = db;

    let newDoc = {};
    newDoc.clientID = clientID;
    newDoc.type = entityType;
    newDoc.data = data;

    self.insert(newDoc, callback);
};


//////////////////////
// Avatar functions // maybe extract this to a child class?
//////////////////////

db.getAllClientAvatars = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+AVATAR;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getAllClientAvatars', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: ' + err, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientAvatars', clientID, null, null, "<<AVATAR : Data fetched from CACHE>>", null, false);
             
            return callback(data);
        }
        logger.info('getAllClientAvatars', clientID, null, null, "<<AVATAR : Data fetched from DB>>", null, false);
         
        getAllClientEntites(clientID, AVATAR, callback);
    });
};

// This is for "external" calls
db.getClientAvatarByName = function (clientID, avatarName, callback) {
    let cacheKey = 'core-'+clientID+'-'+avatarName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientAvatarByName', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientAvatarByName', clientID, null, null, '<<Avatar-'+avatarName+' : Data fetched from CACHE>>', null, false);
             
            return callback(data);
        }
        logger.info('getClientAvatarByName', clientID, null, null, '<<Avatar-'+avatarName+' : Data fetched from DB>>', null, false);
         
        getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (avatar) {
            // store data in cache
            let resultsForCache = avatar ? JSON.stringify(avatar.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(avatar ? avatar.data : null);
        });
    });
};

db.insertClientAvatar = function (clientID, data, callback) {
    // delete old data for getting all avatars
    let cacheKey = 'core-'+clientID+'-'+AVATAR;
    deleteCacheData(cacheKey);

    insertClientEntity(clientID, AVATAR, data, callback)
};

db.updateClientAvatarByName = function (clientID, avatarName, data, callback) {
    let self = db;

    // delete old data for specified avatar
    let cacheKey = 'core-'+clientID+'-'+avatarName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (result) {
        if (!result) {
            logger.error('updateClientAvatarByName', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            copyData(result.data, data);
            self.update(result, callback);
        }
    })
};

db.deleteClientAvatarByName = function (clientID, avatarName, callback) {
    let self = db;

    // delete data for specified avatar
    let cacheKey = 'core-'+clientID+'-'+avatarName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, AVATAR, "name", avatarName, function (avatar) {
        if (!avatar) {
            logger.error('deleteClientAvatarByName', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback(null);
        } else {
            self.delete(avatar, function (err, deleteResult) {
                if (err) {
                    callback(null);
                } else {
                    callback(avatar.data);
                }
            });
        }
    })
};


//////////////////////
// Expertise functions // maybe extract this to a child class?
//////////////////////

db.getAllClientExpertise = function (clientID, callback) {
    getAllClientEntites(clientID, EXPERTISE, callback);
};

// This is for "external" calls
db.getClientExpertiseByName = function (clientID, expertiseName, callback) {
    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (expertise) {
        callback(expertise ? expertise.data : null);
    });
};

db.insertClientExpertise = function (clientID, data, callback) {
    insertClientEntity(clientID, EXPERTISE, data, callback)
};

db.updateClientExpertiseByName = function (clientID, expertiseName, data, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (result) {
        if (!result) {
            logger.error('updateClientExpertiseByName', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            copyData(result.data, data);
            self.update(result, callback);
        }
    })
};

db.deleteClientExpertiseByName = function (clientID, expertiseName, callback) {
    let self = db;

    getClientEntityByKeyValue(clientID, EXPERTISE, "name", expertiseName, function (result) {
        if (!result) {
            logger.error('deleteClientExpertiseByName', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback(null);
        } else {
            self.delete(result, callback);
        }
    })
};


////////////////////////
// Registry functions // maybe extract this to a child class?
////////////////////////

db.getAllClientRegistry = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+REGISTRY;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getAllClientRegistry', clientID, null, null, 'Error while searching clientId in redis: ' + cacheKey + 'Err: '+ err, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientRegistry', clientID, null, null, '<<REGISTRY : Data fetched from CACHE>>', null, false);
             
            return callback(data);
        }
        logger.info('getAllClientRegistry', clientID, null, null, '<<REGISTRY : Data fetched from DB>>', null, false);
         
        getAllClientEntites(clientID, REGISTRY, callback);
    });
};

// This is for "external" calls
db.getClientRegistryByName = function (clientID, expertiseName, callback) {
    let cacheKey = 'core-'+clientID+'-'+expertiseName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientRegistryByName', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientRegistryByName', clientID, null, null, '<<Expertise-'+expertiseName+' : Data fetched from CACHE>>', null, false);
             
            return callback(data);
        }
        logger.info('getClientRegistryByName', clientID, null, null, '<<Expertise-'+expertiseName+' : Data fetched from CACHE>>', null, false);
         
        getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (expertise) {
            // store data in cache
            let resultsForCache = expertise ? JSON.stringify(expertise.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(expertise ? expertise.data : null);
        });
    });
};

db.insertClientRegistry = function (clientID, data, callback) {
    // delete cache data for all expertise
    let cacheKey = 'core-'+clientID+'-'+REGISTRY;
    deleteCacheData(cacheKey);

    insertClientEntity(clientID, REGISTRY, data, callback)
};

db.updateClientRegistryByName = function (clientID, expertiseName, data, callback) {
    let self = db;

    // delete old data from cache for specified expertise and getAllExpertise
    let cacheKeys = [];
    cacheKeys.push('core-'+clientID+'-'+expertiseName);
    cacheKeys.push('core-'+clientID+'-'+REGISTRY);
    deleteCacheData(cacheKeys);

    getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (expertise) {
        if (!expertise) {
            logger.error('updateClientRegistryByName', clientID, null, null, "Problem fetching client's data", null, false);
            
            callback("Problem fetching client's data", null);
        } else {
            copyData(expertise.data, data);
            self.update(expertise, callback);
        }
    })
};

db.deleteClientRegistryByName = function (clientID, expertiseName, callback) {
    let self = db;

    // delete old data from cache for specified expertise and getAllExpertise
    let cacheKeys = [];
    cacheKeys.push('core-'+clientID+'-'+expertiseName);
    cacheKeys.push('core-'+clientID+'-'+REGISTRY);
    deleteCacheData(cacheKeys);

    getClientEntityByKeyValue(clientID, REGISTRY, "name", expertiseName, function (Registry) {
        if (!Registry) {
            logger.error('deleteClientRegistryByName', clientID, null, null, "Problem fetching client's data", null, false);
           
            callback("Problem fetching client's data", null);
        } else {
            self.delete(Registry, callback);
        }
    })
};


////////////////////////
//   Link functions   // maybe extract this to a child class?
////////////////////////

db.getAllClientLinks = function (clientID, callback) {
    let cacheKey = 'core-'+clientID+'-'+LINK;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
           logger.error('getAllClientLinks', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);
           
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientLinks', clientID, null, null, '<<LINK : Data fetched from CACHE>>', null, false);
            
            return callback(data);
        }
        logger.info('getAllClientLinks', clientID, null, null, '<<LINK : Data fetched from DB>>', null, false);
        
        getAllClientEntites(clientID, LINK, callback);
    });
};


let getClientLinkByExpertiseAndAvatarNamesRaw = function (clientID, expertiseName, avatarName, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: avatarName
    });

    pairsArray.push({
        key: "expertise.name",
        value: expertiseName
    });

    getClientEntityByKeyValueArray(clientID, LINK, pairsArray, function (link) {
        callback(link ? link : null);
    });
};

// This is for "external" calls
db.getClientLinkByExpertiseAndAvatarNames = function (clientID, expertiseName, avatarName, callback) {
    getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
        callback(link ? link.data : null);
    });
};

db.getClientExpertiseNamesByAvatar = function (clientID, avatarName, fallback, callback) {
    let cacheKey;
    if (fallback !== undefined) {
        cacheKey = 'core-'+clientID+'-'+avatarName+'-link-expertise-fallback'
    } else {
        cacheKey = 'core-'+clientID+'-'+avatarName+'-link-expertise-nofallback'
    }

    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientExpertiseNamesByAvatar', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getClientExpertiseNamesByAvatar', clientID, null, null, '<<Avatar -'+avatarName+' link-expertise-fallback : Data fetched from CACHE>>', null, false);
             
            return callback(data);
        }

        logger.info('getClientExpertiseNamesByAvatar', clientID, null, null, '<<Avatar -'+avatarName+' link-expertise-fallback : Data fetched from DB>>', null, false);
        
        let pairsArray = [];

        pairsArray.push({
            key: "avatar",
            value: avatarName
        });

        if (fallback !== undefined) {
            pairsArray.push({
                key: "expertise.fallback",
                value: fallback
            });
        }

        getAllClientEntitiesByKeyValueArray(clientID, LINK, pairsArray, function (links) {
            let names = [];

            links.forEach(function (link) {
                names.push(link.data.expertise.name);
            });

            // store data in cache
            let resultsForCache = names.length ? JSON.stringify(names) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(names);
        });
    });
};

db.getClientLinksByAvatar = function (clientID, avatarName, fallback, callback) {
    let pairsArray = [];

    pairsArray.push({
        key: "avatar",
        value: avatarName
    });

    if (fallback !== undefined) {
        pairsArray.push({
            key: "expertise.fallback",
            value: fallback
        });
    }

    getAllClientEntitiesByKeyValueArray(clientID, LINK, pairsArray, function (links) {
        let linksData = [];

        links.forEach(function (link) {
            linksData.push(link.data);
        });

        callback(linksData);
    });
};

db.getClientAvatarsNamesByExpertise = function (clientID, expertiseName, callback) {
    getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", expertiseName, function (links) {
        let names = [];

        links.forEach(function (link) {
            names.push(link.data.avatar);
        });
        callback(names);
    });
};

db.insertClientLink = function (clientID, data, callback) {
    insertClientEntity(clientID, LINK, data, callback)
};

db.updateClientLinkByExpertiseAndAvatarNames = function (clientID, expertiseName, avatarName, data, callback) {
    let self = db;

    getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
        if (!link) {
            logger.error('updateClientLinkByExpertiseAndAvatarNames', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            copyData(link.data, data);
            self.update(link, callback);
        }
    })
};

db.updateAllClientLinkAvatar = function (clientID, oldAvatarName, newAvatarName, callback) {
    let self = db;

    getAllClientEntitiesByKeyValue(clientID, LINK, "avatar", oldAvatarName, function(links) {
        if (!links) {
            logger.error('updateAllClientLinkAvatar', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    link.data.avatar = newAvatarName;
                    self.update(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        }
    });
};

db.updateAllClientLinkExpertise = function (clientID, oldExpertiseName, newExpertiseName, callback) {
    let self = db;

    getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", oldExpertiseName, function(links) {
        if (!links) {
            logger.error('updateAllClientLinkExpertise', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    link.data.expertise.name = newExpertiseName;
                    self.update(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        }
    });
};



db.deleteClientLinkByExpertiseAndOrAvatarNames = function (clientID, expertiseName, avatarName, callback) {
    let self = db;

    if (avatarName && expertiseName) {
        getClientLinkByExpertiseAndAvatarNamesRaw(clientID, expertiseName, avatarName, function (link) {
            if (!link) {
                logger.error('deleteClientLinkByExpertiseAndOrAvatarNames', clientID, null, null, "Problem fetching client's data", null, false);
                 
                callback([]);
            } else {
                self.delete(link, function (err, result) {
                    callback(returnOnlyData([link]));
                });
            }
        })
    } else if (!avatarName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "expertise.name", expertiseName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    } else if (!expertiseName) {
        getAllClientEntitiesByKeyValue(clientID, LINK, "avatar", avatarName, function (links) {
            let tasks = [];

            links.forEach(function (link) {
                tasks.push(function (callb) {
                    self.delete(link, callb)
                });
            });

            // an example using an object instead of an array
            async.parallel(tasks, function (err, result) {
                callback(returnOnlyData(links));
            });
        });
    }
};

//////////////////////
// Manifest functions // maybe extract this to a child class?
//////////////////////

db.getAllClientManifests = function (clientID, callback) {
    getAllClientEntites(clientID, MANIFEST, callback);
};

// This is for "external" calls
db.getClientManifestByExpertise = function (clientID, expertiseName, callback) {
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+expertiseName;
    redis.getKey(cacheKey, function(err, data) {
        if (err) {
            logger.error('getClientManifestByExpertise', clientID, null, null, 'Error while searching clientId in redis: '+ cacheKey + 'Err: '+ err, null, false);
             
        }
        // if data in cache is found, return it
        if (data) {
            data = JSON.parse(data);
            logger.info('getAllClientLinks', clientID, null, null, '<<Manifest By Expertise-'+expertiseName+' : Data fetched from CACHE>>', null, false);
             
            return callback(data);
        }
        logger.info('getAllClientLinks', clientID, null, null, '<<Manifest By Expertise-'+expertiseName+' : Data fetched from DB>>', null, false);
         
        getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", expertiseName, function (manifest) {
            // store data in cache
            let resultsForCache = manifest ? JSON.stringify(manifest.data) : null;
            if(resultsForCache) redis.putKey(cacheKey, resultsForCache, CACHE_EXPIRY);
            callback(manifest ? manifest.data : null);
        });
    });
};

db.insertClientManifest = function (clientID, data, callback) {
    insertClientEntity(clientID, MANIFEST, data, callback)
};

db.updateClientManifestByExpertise = function (clientID, expertiseName, data, callback) {
    let self = db;

    // delete old data
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+expertiseName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", expertiseName, function (manifest) {
        if (!manifest) {
            logger.error('updateClientManifestByExpertise', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback("Problem fetching client's data", null);
        } else {
            copyData(manifest.data, data);
            self.update(manifest, callback);
        }
    })
};

db.deleteClientManifestByExpertise = function (clientID, expertiseName, callback) {
    let self = db;

    // delete old data
    let cacheKey = 'core-'+clientID+'-'+MANIFEST+'-'+expertiseName;
    deleteCacheData(cacheKey);

    getClientEntityByKeyValue(clientID, MANIFEST, "expertiseName", expertiseName, function (manifest) {
        if (!manifest) {
            logger.error('deleteClientManifestByExpertise', clientID, null, null, "Problem fetching client's data", null, false);
             
            callback(null);
        } else {
            self.delete(manifest, function (err, deleteResult) {
                if (err) {
                    callback(null);
                } else {
                    callback(manifest.data);
                }
            });
        }
    })
};


module.exports = db;