/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */


const Responses = require('./responses');
//const logger = require('../../../server/logger');
const logger = require('../../../sagan-logging/logger');
let bl = require('sagan-dev-node-sdk').bl;

module.exports = {
    getAllLinks: getAllLinks,
    getLink: getLink,
    getAllLinkedSkillsOfSkillSet: getAllLinkedSkillsOfSkillSet,
    getAllSkillSetsASkillLinkedTo: getAllSkillSetsASkillLinkedTo,
    bindMultipleSkillsToSkillSet: bindMultipleSkillsToSkillSet,
    bindSkillToMultipleSkillSets: bindSkillToMultipleSkillSets,
    updateBindDataSkillSetAndSkill: updateBindDataSkillSetAndSkill,
    deleteSkillSet: deleteSkillSet,
    deleteSkillFromSkillSet: deleteSkillFromSkillSet
};

/**
 * check if the input parameter is valid -
 *  check if it exists and if it is not empty
 */
function checkParameter(parameter, parameterName, res) {
    if (parameter === undefined) {
        Responses.missingParameter(res, parameterName);
    } else if (parameter === "") {
        Responses.emptyParameter(res, parameterName);
    } else {
        return true;
    }
    return false;
}

// temporary function - to override the avatar field in the link with skillSet when returning it to the user
function renameAvatarToSkillSet(links) {
    links.forEach(function(link) {
        link.skillSet = link.avatar;
        delete link.avatar;
        link.skill = link.expertise;
        delete link.expertise
    });
    return links;
}

// get all links between all skillSets and skills
function getAllLinks(req, res) {
    const clientID = req.headers.clientid;

    bl.configuration.getAllClientLinks(clientID, function (results) {
        Responses.customMessage(res, 200, renameAvatarToSkillSet(results));
    });
}

function getLink(req, res) {
    const clientID = req.headers.clientid;
    const skillSetName = req.swagger.params.skillSetName.value;
    const skillName = req.swagger.params.skillName.value;

    if (checkParameter(skillSetName, "skillSetName", res) &&
        checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientAvatarByName(clientID, skillSetName, function (skillSet) {
            if (!skillSet) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.getClientRegistryByName(clientID, skillName, function (skill) {
                    if (!skill) {
                        Responses.objectNotFound(res, "skill");
                    } else {
                        bl.configuration.getClientLinkByExpertiseAndAvatarNames(clientID, skillName, skillSetName, function (link) {
                            if (!link) {
                                Responses.skillNotLinkedToSkillSet(res, skillSetName, skillName);
                            } else {
                                Responses.customMessage(res, 200, renameAvatarToSkillSet([link])[0]);
                            }
                        })
                    }
                });
            }
        });
    }
}

/**
 * Get all skills which are linked to the specified skillSet
 */
function getAllLinkedSkillsOfSkillSet(req, res) {
    const skillSetName = req.swagger.params.skillSetName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillSetName, "skillSetName", res)) {
        bl.configuration.getClientAvatarByName(clientID, skillSetName, function (result) {
            if (!result) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.getClientLinksByAvatar(clientID, skillSetName, undefined, function (list) {
                    let skillLinks = [];
                    list.forEach(function (link) {
                        skillLinks.push(link.expertise);
                    });
                    let final = {"skillSet": skillSetName, "skills": skillLinks};
                    Responses.customMessage(res, 200, final);
                    //res.json(list);
                });
            }
        });
    }
}

/**
 * Returns all skillSets which an skill is attached to
 */
function getAllSkillSetsASkillLinkedTo(req, res) {
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillName, "skillName", res)) {
        bl.configuration.getClientRegistryByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                bl.configuration.getClientAvatarsNamesByExpertise(clientID, skillName, function (list) {
                    Responses.customMessage(res, 200, list);
                    //res.json(list);
                });
            }
        });
    }
}

/**
 * inner function - a recursion to handle all the skills linking to skillSet
 * and returning one message for all of them
 */
function bindListOfSkillsToSkillSet(clientID, message, skillList, skillSet, fallbackData, index, goodStatus, res) {
    if (index < skillList.length) {
        bl.configuration.getClientRegistryByName(clientID, skillList[index], function (skillResult) {
            if (!skillResult) {
                message.push("skill with the name of " + skillList[index] + " does not exist");
                bindListOfSkillsToSkillSet(clientID, message, skillList, skillSet, fallbackData, index + 1, goodStatus, res);
            } else {
                bl.configuration.getClientLinkByExpertiseAndAvatarNames(clientID, skillList[index], skillSet.name, function (result) {
                    if (result) {
                        message.push("link between " + skillSet.name + " and " + skillList[index] + " already exists");
                        bindListOfSkillsToSkillSet(clientID, message, skillList, skillSet, fallbackData, index + 1, goodStatus, res);
                    } else {
                        const link = {
                            "avatar": skillSet.name,
                            "expertise": {"name": skillList[index], "fallback": fallbackData}
                        };

                        bl.configuration.insertClientLink(clientID, link, function (err, addResult) {
                            if (err) {
                                message.push("unknown error occurred while adding the link between " +
                                    skillSet.name + " and " + skillList[index]);
                                bindListOfSkillsToSkillSet(clientID, message, skillList, skillSet, fallbackData, index + 1, goodStatus, res);
                            } else {
                                logger.info('bindListOfSkillsToSkillSet', clientID, null, null, "link between " + skillSet.name + " and " + skillList[index] + " added", null, true);
                                 
                                message.push("link between " + skillSet.name + " and " + skillList[index] + " added");
                                bindListOfSkillsToSkillSet(clientID, message, skillList, skillSet, fallbackData, index + 1, true, res);
                            }
                        })
                    }
                })
            }
        })
    } else {
        let statusCode = 201; // defalut
        if (!goodStatus) {
            if (message[0].startsWith("skill with")) {
                statusCode = 404;
            } else if (message[0].startsWith("link between")) {
                statusCode = 409;
            } else {
                statusCode = 400;
            }
        }
        if (message.length === 1) {
            message = message[0]; // if there was only 1 - return as string
        }
        Responses.customMessage(res, statusCode, message);
    }
}

/**
 * Bind multiple skills (or one) to an skillSet
 */
function bindMultipleSkillsToSkillSet(req, res) {
    // Get parameters
    const skillSetName = req.swagger.params.skillSetName.value;
    const skillsData = req.swagger.params.skillsData.value;
    const clientID = req.headers.clientid;
    // Do request
    let message = [];
    if (checkParameter(skillSetName, "skillSetName", res) &&
        checkParameter(skillsData, "skillsData", res) &&
        checkParameter(skillsData.skillNames, "skillsData.skillNames", res) &&
        checkParameter(skillsData.fallback, "skillsData.fallback", res)) {
        bl.configuration.getClientAvatarByName(clientID, skillSetName, function (skillSet) {
            if (!skillSet) {
                Responses.objectNotFound(res, "skillSet");
            } else if (typeof (skillsData.skillNames) !== "string" && skillsData.skillNames.length === 0) {
                Responses.emptyParameter(res, "skillsData.skillNames");
            }
            else {
                let skillsList = skillsData.skillNames;
                if (typeof(skillsData.skillNames) === "string") {
                    // only one skill is given - insert it into array
                    skillsList = [skillsData.skillNames];
                }
                bindListOfSkillsToSkillSet(clientID, message, skillsList, skillSet, skillsData.fallback, 0, false, res);
            }
        })
    }
}

function deleteSkillSet(req, res) {
    const name = req.swagger.params.skillSetName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(name, "skillSetName", res)) {
        bl.configuration.getClientAvatarByName(clientID, name, function (hasResult) {
            if (!hasResult) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.deleteClientAvatarByName(clientID, name, function (removeResult) {
                    if (!removeResult) {
                        Responses.badRequestUnknownFailure(res,clientID);
                    } else {
                        bl.configuration.deleteClientLinkByExpertiseAndOrAvatarNames(clientID, undefined, name, function (result) { // Not checking result - maybe there are no links
                            if (!result) {
                                Responses.badRequestUnknownFailure(res,clientID);
                            } else {
                                logger.info('deleteSkillSet', clientID, req.id, null,"deleted skillSet - " + name , null, true);
                                 
                                Responses.deletedSuccessfully(res, "skillSet");
                            }
                        });
                    }
                })
            }
        });
    }
}


/**
 * inner function - a recursion to handle all the skillSet linking to a skill
 * and returning one message for all of them
 */
function bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, fallbackData, index, goodStatus, res) {
    if (index < skillSetsList.length) {
        bl.configuration.getClientAvatarByName(clientID, skillSetsList[index], function (skillSet) {
            if (!skillSet) {
                message.push("skillSet with the name of " + skillSetsList[index] + " does not exist");
                bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, fallbackData, index + 1, goodStatus, res);
            } else {
                bl.configuration.getClientLinkByExpertiseAndAvatarNames(clientID, skill.name, skillSet.name, function (result) {
                    if (result) {
                        message.push("link between " + skillSetsList[index] + " and " + skill.name + " already exists");
                        bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, fallbackData, index + 1, goodStatus, res);
                    } else {
                        const link = {
                            "avatar": skillSet.name,
                            "expertise": {"name": skill.name, "fallback": fallbackData}
                        };

                        bl.configuration.insertClientLink(clientID, link, function (err, addResult) {
                            if (err) {
                                message.push("unknown error occurred while adding the link between " +
                                    skillSetsList[index] + " and " + skill.name);
                                bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, fallbackData, index + 1, goodStatus, res);
                            } else {
                                logger.info('bindListOfSkillSetsToSkill', clientID, null, null, "link between " + skillSetsList[index] + " and " + skill.name + " added", null, true);
                                 
                                message.push("link between " + skillSetsList[index] + " and " + skill.name + " added");
                                bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, fallbackData, index + 1, true, res);
                            }
                        })
                    }
                })
            }
        })
    } else {
        if (message.length === 1) {
            message = message[0]; // if there was only 1 - return as string
        }
        let statusCode = 201; // defalut
        if (!goodStatus) {
            if (message.startsWith("skillSet with")) {
                statusCode = 404;
            } else if (message.startsWith("skillSet name")) {
                statusCode = 400;
            } else {
                statusCode = 409;
            }
        }
        Responses.customMessage(res, statusCode, message);
    }
}

/**
 * Bind skill to multiple skillSets
 */
function bindSkillToMultipleSkillSets(req, res) {
    // Get parameters
    const skillName = req.swagger.params.skillName.value;
    const skillSetsData = req.swagger.params.skillSetsData.value;
    const clientID = req.headers.clientid;
    // Do request
    if (checkParameter(skillName, "skillName", res) && checkParameter(skillSetsData) &&
        checkParameter(skillSetsData.skillSets, "skillSetsData.skillSets", res) &&
        checkParameter(skillSetsData.fallback, "skillSetsData.fallback", res)) {
        bl.configuration.getClientRegistryByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else if (typeof (skillSetsData.skillSets) !== "string" &&
                skillSetsData.skillSets.length === 0) {
                Responses.emptyParameter(res, "skillSetsData.skillSets");
            } else {
                let message = [];
                let skillSetsList = skillSetsData.skillSets;
                if (typeof(skillSetsData.skillSets) === "string") {
                    // only one skill is given - insert it into array
                    skillSetsList = [skillSetsData.skillSets];
                }
                // check each skillSet - if it exist, and if it is already linked to this skill
                bindListOfSkillSetsToSkill(clientID, message, skillSetsList, skill, skillSetsData.fallback, 0, false, res);
            }
        })
    }
}

/**
 * update the link details between skill and skillSet
 */
function updateBindDataSkillSetAndSkill(req, res) {
    const skillSetName = req.swagger.params.skillSetName.value;
    const skillName = req.swagger.params.skillName.value;
    const data = req.swagger.params.data.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillSetName, "skillSetName", res) &&
        checkParameter(skillName, "skillName", res) &&
        checkParameter(data, "data", res) &&
        checkParameter(data.fallback, "data.fallback", res)) {
        bl.configuration.getClientAvatarByName(clientID, skillSetName, function (skillSet) {
            if (!skillSet) {
                Responses.objectNotFound(res, "skillSet");
            } else {
                bl.configuration.getClientRegistryByName(clientID, skillName, function (skill) {
                    if (!skill) {
                        Responses.objectNotFound(res, "skill");
                    } else {
                        const link = {
                            "avatar": skillSetName,
                            "expertise": {"name": skillName, "fallback": data.fallback}
                        };
                        bl.configuration.getClientLinkByExpertiseAndAvatarNames(clientID, skill.name, skillSet.name, function (linked) {
                            if (!linked) {
                                Responses.skillNotLinkedToSkillSet(res, skillSetName, skillName);
                            } else {
                                bl.configuration.updateClientLinkByExpertiseAndAvatarNames(clientID, skillName, skillSetName, link, function (err, updated) {
                                    if (err) {
                                        Responses.badRequestUnknownFailure(res,clientID);
                                    } else {
                                        logger.info('updateBindDataSkillSetAndSkill', clientID, req.id, null, "Updated attachment data between " + skillSetName + " and " + skillName, null, true);
                                         
                                        Responses.updatedSuccessfully(res, "link");
                                    }
                                })
                            }
                        })
                    }
                })
            }
        })
    }
}

/**
 * Unbind skill from skillSet
 */
function deleteSkillFromSkillSet(req, res) {
    // Get parameters
    const skillSetName = req.swagger.params.skillSetName.value;
    const skillName = req.swagger.params.skillName.value;
    const clientID = req.headers.clientid;

    if (checkParameter(skillSetName, "skillSetName", res) &&
        checkParameter(skillName, "skillName", res)) {
        // all the details are not empty - Remove skillSet-skill link
        bl.configuration.getClientRegistryByName(clientID, skillName, function (skill) {
            if (!skill) {
                Responses.objectNotFound(res, "skill");
            } else {
                bl.configuration.getClientAvatarByName(clientID, skillSetName, function (skillSet) {
                    if (!skillSet) {
                        Responses.objectNotFound(res, "skillSet");
                    } else {
                        bl.configuration.getClientLinkByExpertiseAndAvatarNames(clientID, skillName, skillSetName, function (link) {
                            if (!link) {
                                Responses.skillNotLinkedToSkillSet(res, skillSetName, skillName);
                            } else {
                                bl.configuration.deleteClientLinkByExpertiseAndOrAvatarNames(clientID, skillName, skillSetName, function (result) {
                                    if (!result) {
                                        Responses.badRequestUnknownFailure(res,clientID);
                                    } else {
                                        logger.info('deleteSkillFromSkillSet', clientID, req.id, null, "Unbind " + skillName + " from " + skillSetName, null, true);
                                         
                                        Responses.deletedSuccessfully(res, "link");
                                    }
                                });
                            }
                        })
                    }
                });
            }
        });
    }
}
