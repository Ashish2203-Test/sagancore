const LogmetClient = require('../lib/logmet-client/client');

describe("Test logger", function() {
	/*
	it("Direct logmet client test using super tenant id", function() {
	  loggingClientWA = new LogmetClient({
		host: "ingest.logging.ng.bluemix.net",
		port: 9091,
		tenantId: "WatsonAssistant",
		logger: 'trace',
		timeoutSeconds: 30,
		isSupertenant: true,
		tenantPassword: "vcGqXKnJ8mOo"
	  });
	  console.log('Created logmet client instance');

	  let message = new Map();
	  message.set('type', 'WatsonAssistant');
	  message.set('logLevel', 'INFO');
	  message.set('appName', 'sagan-logging');
	  message.set('clientId', 'client-0099');
	  message.set('requestId', 'requestId-4563');
	  message.set('message', 'testing for direct message using super tenant id');
	  // message.set('ALCH_TENANT_ID', 'f6245834-45d8-44f4-88eb-f520359c371f');
	  message.set('ALCH_TENANT_ID', 'db40a5d0-baf8-4540-9ea2-c0dd5fc4c115');
	  console.log('sending message ', message);
	  
	  loggingClientWA.addLogMessage(message);

	  console.log('Successfully sent message');
	});

	it("Direct logmet client test", function() {
	  loggingClientWA = new LogmetClient({
		host: "ingest.logging.ng.bluemix.net",
		port: 9091,
		tenantId: "f6245834-45d8-44f4-88eb-f520359c371f",
		logger: 'trace',
		timeoutSeconds: 30,
		tenantPassword: "jA2pbX0_srXW"
	  });

	  console.log('Created logmet client instance');

	  let message = new Map();
	  message.set('type', 'WatsonAssistant');
	  message.set('logLevel', 'INFO');
	  message.set('appName', 'sagan-logging');
	  message.set('clientId', 'client-0099');
	  message.set('requestId', 'requestId-4563');
	  message.set('message', 'testing for direct message');
	  message.set('ALCH_TENANT_ID', 'f6245834-45d8-44f4-88eb-f520359c371f');
	  loggingClientWA.addLogMessage(message);

	  console.log('Successfully sent message');
	});

	it("Test logmetClient logger", function() {
		process.env.LOGGING_CLIENT_TYPE = 'logmetClient';
		var logger = require('../logger');
		process.env.BMX_ENV = 'production-dev';
		logger.init(process.env.BMX_ENV);

		logger.info('testMethod', 'asdf-ghjk-rtyu', 'w23e-rt4y-i67y', null, 'Test info message from logger test', null, false);
		logger.error('testMethod', 'asdf-ghjk-rtyu', 'w23e-rw4y-f67y', null, 'Test error message from logger test', null, false);
	});
	*/

	it("Test super tenant function", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		process.env.LOGGING_CLIENT_TYPE = 'logmetClient';
		var logger = require('../logger');
		process.env.BMX_ENV = 'production-dev';
		logger.init(process.env.BMX_ENV);

		setTimeout(function() {
			logger.debug('testMethod', '1a233cd8-9d47-4f8c-a140-3420ad4bd6e5', 'w23e-rw4y-f67y', null, 'Test error message from logger test', null, true);
			done();
		}, 3000)
	});

	/*
	it("Test winston client", function() {
		var logger = require('../logger');
		process.env.BMX_ENV = 'production-dev';
		logger.init(process.env.BMX_ENV);

		logger.info('testMethod', 'asdf-ghjk-rtyu', 'w23e-rt4y-i67y', null, 'Test info message for winston logger', null, false);
		logger.error('testMethod', 'asdf-ghjk-rtyu', 'w23e-rw4y-f67y', null, 'Test error message for winston logger', null, false);
	});

	it("Test create mapping", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.saveMapping('1a233cd8-9d47-4f8c-a140-3420ad4bd6e5', 'db40a5d0-baf8-4540-9ea2-c0dd5fc4c115', function (err, result) {
			if (err) {
				console.error(err);
				done();
			} else {
				console.log(result);
				done();
			}
		});
	});	

	it("Test find mapping", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.getTenantId('1a233cd8-9d47-4f8c-a140-3420ad4bd6e5', function (err, result) {
			if (err) {
				console.error(err);
				done();
			} else {
				console.log(result);
				done();
			}
		});
	});	

	it("Test find mapping from cache", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.getTenantId('client-001', function (err, result) {
			if (err) {
				console.error(err);
				done();
			} else {
				console.log(result);
				done();
			}
		});
	});	

	it("Test find mapping for invalid client", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.getTenantId('client-002', function (err, result) {
			if (err) {
				console.error(err);
			} else {
				if (!result) {
					console.error('Tenant not found');
					done();
				}
				else {
					console.log('Found tenant:', result);
					done();
				}
			}
		});
	});	

	it("Test delete mapping for invalid client", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.deleteMapping('client-002', function (err, result) {
			if (err) {
				console.error(err);
			} else {
				if (!result)
					console.error('Tenant not found');
				else 
					console.log('Deleted mapping:', result);
					
				done();
			}
		});
	});	

	it("Test delete mapping for valid client", function(done) {
		process.env.VCAP_SERVICES = '{ "Auto-Scaling": [{ "credentials": {"agentPassword": "bf66c959-16a2-4649-af45-67f58f2c01ee","agentUsername": "agent","api_url": "https://ScalingAPI.ng.bluemix.net","app_id": "567beef1-6b63-44c4-a656-6b6ec9d2216b","service_id": "7275d249-936e-41d1-9c45-84a95145d61d","url": "https://Scaling3.ng.bluemix.net" }, "label": "Auto-Scaling", "name": "sagan-autoscaling", "plan": "free", "provider": null, "syslog_drain_url": null, "tags": ["bluemix_extensions","ibm_created","dev_ops" ], "volume_mounts": []} ], "cloudantNoSQLDB": [{ "credentials": {"host": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","password": "8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96","port": 443,"url": "https://0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix:8cfd7f8462458e3865456b124b0ad261e160f9a2e7cf74a7ca47248e04aa8a96@0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix.cloudant.com","username": "0e7457d1-5cb4-4ffd-86a1-3931cb69c19f-bluemix" }, "label": "cloudantNoSQLDB", "name": "SaganHub-Cloudant", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["data_management","ibm_created","lite","ibm_dedicated_public" ], "volume_mounts": []} ], "compose-for-redis": [{ "credentials": {"db_type": "redis","deployment_id": "59e5e8b246c6f00018a23e20","maps": [],"misc": { "cli_readonly": [], "direct_readonly": [], "ssh_cli": []},"name": "bmix-dal-yp-81a1230a-b34f-4a98-94a6-fcb8fb51c917","uri": "redis://admin:NCZDWWLAALKUDKHG@sl-us-south-1-portal.11.dblayer.com:25079","uri_cli": "redis-cli -h sl-us-south-1-portal.11.dblayer.com -p 25079 -a NCZDWWLAALKUDKHG" }, "label": "compose-for-redis", "name": "sagan-redis", "plan": "Standard", "provider": null, "syslog_drain_url": null, "tags": ["big_data","data_management","ibm_created","ibm_dedicated_public" ], "volume_mounts": []} ], "dashDB For Transactions": [{ "credentials": {"db": "BLUDB","dsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;","host": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","hostname": "dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net","https_url": "https://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:8443","jdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","password": "OGY3YWQyMDY3OTVk","port": 50000,"ssldsn": "DATABASE=BLUDB;HOSTNAME=dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net;PORT=50001;PROTOCOL=TCPIP;UID=bluadmin;PWD=OGY3YWQyMDY3OTVk;Security=SSL;","ssljdbcurl": "jdbc:db2://dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50001/BLUDB:sslConnection=true;","uri": "db2://bluadmin:OGY3YWQyMDY3OTVk@dashdb-txn-flex-yp-dal09-20.services.dal.bluemix.net:50000/BLUDB","username": "bluadmin" }, "label": "dashDB For Transactions", "name": "sagan-admin-console-dashdb", "plan": "EnterpriseForTransactionsFlex", "provider": null, "syslog_drain_url": null, "tags": ["big_data","ibm_created","db2","sqldb","purescale","sql","ibm_dedicated_public","db2 on cloud","db2oncloud","dash","dashdb","oracle","database","transactions","flex","dbaas" ], "volume_mounts": []} ]}';
		var client = require('../lib/mapping');

		client.deleteMapping('client-001', function (err, result) {
			if (err) {
				console.error(err);
			} else {
				if (!result)
					console.error('Tenant not found');
				else 
					console.log('Deleted mapping:', result);
					
				done();
			}
		});
	});
	*/
});
