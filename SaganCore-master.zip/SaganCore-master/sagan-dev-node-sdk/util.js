/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var util = {};

var https = require('https');
var querystring = require('querystring');
var auth = require('basic-auth');
var request = require('request');
var bl = require("./bl.js");
var credentials = require('./credentials.js');

util.randomIotCredentialsIdentifier = function () {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }

    return s4() + s4() + s4();
};

util.getUserName = function (req) {
    var credentials = auth(req);
    if (credentials) {
        return credentials.name;
    }
    else {
        throw {
            'code': 401,
            'message': 'forbidden'
        };
    }
};

util.validateUserPass = function (username, password, callback) {

    if (username && password) {
        bl.user.checkUserCredentialsFull(username, password, function (err, doc) {
            if (err) {
                console.log(err);
                callback(err, null);
            } else {
                //console.log("isUserCredentialsVerified="+isUserCredentialsVerified);
                callback(null, doc);
            }
        });
    } else {
        callback("no crdentials", false);
    }
};

util.httpPostCall = function (hostname, URI, api_key, auth_token, res, queryObj, sendCred, post_data, callback) {
    var iotres;
    // An object of options to indicate where to post to
    var post_options = {
        hostname: hostname,
        port: 443,
        rejectUnauthorized: false,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': post_data.length
        }
    };

    post_options.auth = api_key + ':' + auth_token;
    post_options.path = URI;

    if (queryObj) {
        //console.log("Query called with : "+querystring.stringify(queryObj));
        post_options.path = URI + "?" + querystring.stringify(queryObj);
    }

    //console.log("post_options="+JSON.stringify(post_options));
    var http_req = https.request(post_options, function (http_res) {
        http_res.setEncoding('utf8');

        var data = [];
        http_res.on('data', function (chunk) {
            data.push(chunk);
        });

        http_res.on('end', function () {
            if (data.length === 0) {
                callback("no data found", null);
            } else {
                // a non-empty body does not equal success. Check the status code before deciding if the method succeeded or not
                // if the status code is 400 or higher return the body as the error message
                if (http_res.statusCode >= 400) {
                    callback(data.join(''), null);
                } else {
                    iotres = JSON.parse(data.join(''));
                    callback(null, iotres);
                }
            }
        });
    });

    http_req.write(post_data);
    http_req.end();

    http_req.on('error', function (e) {
        callback(e, null);
        console.log('Request for ' + post_options.path + ' failed with : \n' + e);
        if (res)
            res.status(500).send(e);
    });

};

util.httpGetCall = function (hostname, URI, api_key, auth_token, res, queryObj, sendCred, callback) {
    var iotres;
    // An object of options to indicate where to post to
    var post_options = {
        hostname: hostname,
        port: 443,
        rejectUnauthorized: false,
        method: 'GET'
    };

    post_options.auth = api_key + ':' + auth_token;
    post_options.path = URI;

    if (queryObj) {
        //console.log("Query called with : "+querystring.stringify(queryObj));
        post_options.path = URI + "?" + querystring.stringify(queryObj);
    }

    //console.log("post_options="+JSON.stringify(post_options));
    var http_req = https.request(post_options, function (http_res) {
        http_res.setEncoding('utf8');

        var data = [];
        http_res.on('data', function (chunk) {
            data.push(chunk);
        });

        http_res.on('end', function () {
            if (data.length === 0) {
                callback("no data found", null);
            } else {
                // a non-empty body does not equal success. Check the status code before deciding if the method succeeded or not
                // if the status code is 400 or higher return the body as the error message
                if (http_res.statusCode >= 400) {
                    callback(data.join(''), null);
                } else {
                    iotres = JSON.parse(data.join(''));
                    callback(null, iotres);
                }
            }
        });
    });

    http_req.end();

    http_req.on('error', function (e) {
        callback(e, null);
        console.log('Request for ' + post_options.path + ' failed with : \n' + e);
        if (res)
            res.status(500).send(e);
    });

};


//Update Node Red Shield Assoc.
util.updateNRSAssoc = function (callback) {
    util.httpPostCall(util.wearredurl, 'refreshassoc', '', '', null, null, true, '', function (err, wresponse) {
        if (callback)
            callback(err, wresponse);
    });
};

util.forward = function (pattern, host) {
    return function (req, res, next) {
        if (req.url.match(pattern)) {
            var db_path = req.url.match(pattern)[1],
                db_url = [host, db_path].join('/');
            req.pipe(request[req.method.toLowerCase()](db_url)).pipe(res);
        } else {
            next();
        }
    };
};


util.clone = function (doc, newdoc) {
    for (var i in newdoc) {
        if (doc.hasOwnProperty(i)) {
            doc[i] = newdoc[i];
        }
    }
    return doc;
};

util.httpPutCall = function (hostname, URI, api_key, auth_token, res, queryObj, post_data, contentType, callback) {
    var iotres;
    // An object of options to indicate where to post to
    var post_options = {
        hostname: hostname,
        port: 443,
        rejectUnauthorized: false,
        method: 'PUT',
        headers: {
            'Content-Type': contentType,
            'Content-Length': post_data.length
        }
    };

    post_options.auth = api_key + ':' + auth_token;
    post_options.path = URI;

    if (queryObj) {
        //console.log("Query called with : "+querystring.stringify(queryObj));
        post_options.path = URI + "?" + querystring.stringify(queryObj);
    }

    var http_req = https.request(post_options, function (http_res) {
        http_res.setEncoding('utf8');

        var data = [];
        http_res.on('data', function (chunk) {
            data.push(chunk);
        });

        http_res.on('end', function () {
            // a non-empty body does not equal success. Check the status code before deciding if the method succeeded or not
            // if the status code is 400 or higher return the body as the error message
            if (http_res.statusCode >= 400) {
                callback(data.length === 0 ? http_res.statusMessage : data.join(''), null);
            } else {
                iotres = JSON.parse(data.join(''));
                callback(null, iotres);
            }
        });
    });

    http_req.write(post_data);
    http_req.end();

    http_req.on('error', function (e) {
        callback(e, null);
        console.log('Request for ' + post_options.path + ' failed with : \n' + e);
        if (res)
            res.status(500).send(e);
    });

};

util.httpDeleteCall = function (hostname, URI, api_key, auth_token, res, queryObj, post_data, callback) {
    var iotres;
    // An object of options to indicate where to post to
    var post_options = {
        hostname: hostname,
        port: 443,
        rejectUnauthorized: false,
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': post_data.length
        }
    };

    post_options.auth = api_key + ':' + auth_token;
    post_options.path = URI;

    if (queryObj) {
        //console.log("Query called with : "+querystring.stringify(queryObj));
        post_options.path = URI + "?" + querystring.stringify(queryObj);
    }

    console.log(post_options);
    var http_req = https.request(post_options, function (http_res) {
        http_res.setEncoding('utf8');

        var data = [];
        http_res.on('data', function (chunk) {
            data.push(chunk);
        });

        http_res.on('end', function () {
            try {
                // a non-empty body does not equal success. Check the status code before deciding if the method succeeded or not
                // if the status code is 400 or higher return the body as the error message
                if (http_res.statusCode >= 400) {
                    callback(data.length === 0 ? http_res.statusMessage : data.join(''), null);
                } else {
                    iotres = JSON.parse(data.join(''));
                    callback(null, iotres);
                }
            } catch (e) {
                callback(null, "ok");
            }
        });
    });

    http_req.write(post_data);
    http_req.end();

    http_req.on('error', function (e) {
        callback(e, null);
        console.log('Request for ' + post_options.path + ' failed with : \n' + e);
        if (res)
            res.status(500).send(e);
    });
};


util.getCurrentNSBSShiftID = function (timestamp, callback) {

    /*var shiftBoundries = [0,23]; // UTC time
     var current_hour = timestamp.getHours();
     //console.log('current_hour ='+current_hour);
     //console.log('current datetime ='+timestamp);
     var previousDayDate = new Date(timestamp);
     previousDayDate.setDate(timestamp.getDate()-1);

     //console.log('previousDayDate='+previousDayDate);

     var shiftID = ' S2';

     if (current_hour >= shiftBoundries[0] && current_hour<shiftBoundries[1]){
     // 1st shift
     timestamp.setHours(0,0,0,0);

     //console.log(current_hour+' >= '+shiftBoundries[0]+'&&'+current_hour+'<'+shiftBoundries[1]);
     shiftID = ' S1';

     callback(timestamp.toDateString()+shiftID);
     } else if (current_hour < shiftBoundries[0]) {
     // night shift from previous day
     previousDayDate.setHours(0,0,0,0);
     shiftID = ' S2';

     callback(previousDayDate.toDateString()+shiftID);
     } else {
     // night shift
     timestamp.setHours(0,0,0,0);
     shiftID = ' S2';

     callback(timestamp.toDateString()+shiftID);
     }*/

    callback('1');
};

util.validateUser = function (req, res, accessLevel, callback) {
    var credentials = auth(req);
    //console.log("credentials="+JSON.stringify(credentials));
    if (credentials) {
        bl.user.checkUserCredentialsFull(credentials.name, credentials.pass, function (err, doc) {
            if (err) {

                callback(err, null);
            } else {
                var userAccessLevel = doc.accessLevel || 999;
                callback(null, accessLevel >= userAccessLevel);
            }
        });
    }
};

util.sendMail = function (fromMail, toList, title, body, callback) {
    var sendmail = require('sendmail')();
    sendmail({
        from: fromMail,
        to: toList,
        subject: title,
        content: body
    }, callback);
};

util.getObjectStorageConfig = function (callback) {
    var objectStorageCredentials = credentials.getCredentialsByServiceName('Object-Storage');

    //Create a config object
    var config = {};

    //Specify Openstack as the provider
    config.provider = "openstack";

    //Authentication url
    config.authUrl = 'https://identity.open.softlayer.com/';
    config.region = 'dallas';

    //Use the service catalog
    config.useServiceCatalog = true;

    //true for applications running inside Bluemix, otherwise false
    config.useInternal = false;

    //projectId as provided in your Service Credentials
    config.tenantId = objectStorageCredentials.projectId;

    //userId as provided in your Service Credentials
    config.userId = objectStorageCredentials.userId;

    //username as provided in your Service Credentials
    config.username = objectStorageCredentials.username;

    //password as provided in your Service Credentials
    config.password = objectStorageCredentials.password;

    //This is part which is NOT in original pkgcloud. This is how it works with newest version of bluemix and pkgcloud at 22.12.2015.
    //In reality, anything you put in this config.auth will be send in body to server, so if you need change anything to make it work, you can. PS : Yes, these are the same credentials as you put to config before.
    //I do not fill this automatically to make it transparent.

    config.auth = {
        forceUri: "https://identity.open.softlayer.com/v3/auth/tokens", //force uri to v3, usually you take the baseurl for authentication and add this to it /v3/auth/tokens (at least in bluemix)
        interfaceName: "public", //use public for apps outside bluemix and internal for apps inside bluemix. There is also admin interface, I personally do not know, what it is for.
        "identity": {
            "methods": [
                "password"
            ],
            "password": {
                "user": {
                    "id": objectStorageCredentials.userId, //userId
                    "password": objectStorageCredentials.password //userPassword
                }
            }
        },
        "scope": {
            "project": {
                "id": objectStorageCredentials.projectId //projectId
            }
        }
    };

    callback(config);
};


util.readFileFromStorage = function (containerName, fileName, callback) {

    var pkgcloud = require('pkgcloud-bluemix-objectstorage');

    util.getObjectStorageConfig(function (config) {

        //Create a pkgcloud storage client
        var storageClient = pkgcloud.storage.createClient(config);

        //Authenticate to OpenStack
        storageClient.auth(function (error) {
            if (error) {
                console.dir(error);
                callback(null, error);
            }
            else {
                // Print the identity object which contains your Keystone token.
                //console.log("storageClient.auth() : created storage client: " + JSON.stringify(storageClient._identity));

                /*var stream = storageClient.download({
                 container: containerName,
                 remote: fileName
                 }).pipe(fs.createWriteStream(fileName));

                 stream.on('data', function (data) {
                 callback(data,null);
                 });*/

                if (!containerName)
                    storageClient.getContainers(function (err, containers) {
                        if (err) {
                            console.dir(err);
                            callback(null, err);
                        }

                        //containers.forEach(function (container) {
                        // console.log(container.toJSON());
                        callback(containers, null);
                        //});
                    });
                else if (containerName && !fileName) {
                    storageClient.getFiles(containerName, false, function (err, files) {
                        if (err) {
                            console.dir(err);
                            callback(null, err);
                        } else {
                            callback(files, null);
                        }
                    });
                } else {

                    var options = {
                        container: containerName,
                        remote: fileName
                    };

                    var stream = storageClient.download(options, function (err, res) {
                        if (err) {
                            if (fileName.indexOf('usage') === -1)
                                console.dir(err);

                            callback(null, err);
                        } else {
                            //console.log(res);
                        }
                    });

                    var string = '';
                    stream.on('data', function (data) {
                        string += data;
                        //console.log('stream data ' + data);
                    });


                    stream.on('end', function () {
                        //console.log('final output ' + string);
                        callback(string, null);
                    });
                }
            }
        });
    });
};

util.simplePost = function (URI, post_data, callback) {
    var options = {
        uri: URI,
        method: 'POST',
        json: post_data
    };

    request(options, function (error, response, body) {
        if (error) {
            callback(error, null);
        } else if (response.statusCode == 200) {
            callback(null, body);
        } else {
            callback(response, null)
        }
    });
};

module.exports = util;
