/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


//
// The Following test the new Override Credentials using
// Package.json script:  example-using-external-dbs
//
var api = require('./api/api.js');

api.startServer();