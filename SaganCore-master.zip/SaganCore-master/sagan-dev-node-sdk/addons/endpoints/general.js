/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


module.exports = {
  getHealthCheck: getHealthCheck,
  getConfiguration: getConfiguration
};

function getConfiguration(req, res) {
  res.json({
    logger: {
      level: process.env.LOGGER_LEVEL,
    },
    logs: {
      clearOnStartup: process.env.LOGS_CLEAR
    },
    storage: {
      type: process.env.STORAGE
    },
    contract: {
      type: process.env.CONTRACT,
      version: process.env.CONTRACT_VERSION
    },
    persistent: {
      enabled: process.env.PERSIST || 'false',
      type: process.env.PERSISTENT
    }
  });
}

function getHealthCheck(req, res) {
  res.json();
}
