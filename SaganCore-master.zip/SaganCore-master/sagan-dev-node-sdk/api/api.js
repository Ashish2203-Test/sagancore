/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */


'use strict';

const path = require('path');
const SwaggerExpress = require('swagger-express-mw');
const swaggerUi = require('swagger-tools/middleware/swagger-ui');
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const config = require('../config.js');

let endpointLoader = require('./endpoint-loader.js');

let wfconfig = config.loadRootConfigFile();
let api = {};
let app = express();

let swaggerJson = require(path.join(__dirname, 'swagger.json'));
let bagpipesJson = require(path.join(__dirname, '/config/', 'bagpipes.json'));

// load paths to bagpipes json;
let swaggerConfig = {
    appRoot: __dirname, // required config
    bagpipes: bagpipesJson,
    swagger: swaggerJson
};

// This is a trick to change the base path
// https://stackoverflow.com/questions/36313015/change-basepath-for-swagger-ui
let basePathApp = express();

api.startServer = function () {

    endpointLoader.loadEndpoints(bagpipesJson, swaggerJson);

    SwaggerExpress.create(swaggerConfig, function (err, swaggerExpress) {

        if (err) {
            throw err;
        }

        app.use(bodyParser.json());
        app.use(bodyParser.urlencoded({extended: false}));
        app.use(session({
            secret: 'secret',
            resave: false,
            saveUninitialized: false
        }));

        let basePath = swaggerExpress.runner.api.basePath;

        // Add swagger-ui (This must be before swaggerExpress.register)
        app.use(basePath, basePathApp);
        basePathApp.use(swaggerUi(swaggerExpress.runner.swagger));

        app.get('/api-docs', (req, res) => {
            res.redirect(path.join(basePath, '/api-docs'));
        })

        // Redirect to swagger page
        app.get('/', function (req, res) {
                res.redirect(path.join(basePath, '/docs'));
            }
        );

        process.setMaxListeners(0);

        process.on('uncaughtException', function (error) {
            console.log("ERROR " +
                "module = api, " +
                "function = uncaughtException, " +
                "error = " + JSON.stringify(error) + ", " +
                "message = Server fail, not exiting");
        });

        let port;

        if (config.localPorts) {
            port = wfconfig.api.host.port;
        } else {
            port = process.env.PORT || 8080;
        }

        // install middleware
        swaggerExpress.register(app);

        app.listen(port, function () {
            console.log("Express server listening on port " + port);
        });

        api.swagger = swaggerExpress;
    });
};

// Checks that the request for the API came from the HUB (request is from the same space)
app.all('/*', function (req, res, next) {
    // Only check that if we are not on debug mode
    if (!config.workingOnLocalDeveloperLaptop && wfconfig.enforceSpaceKeyCheck) {
        let spaceKey = req.headers["space-key"];

        if (process.env.SPACE_KEY !== spaceKey) {
            res.sendStatus(401);
        } else {
            next();
        }
    } else {
        next();
    }
});

api.app = app;
module.exports = api;