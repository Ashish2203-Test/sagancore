/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var credExport = require('./credentials.js');
var utilExport = require('./util.js');
var blExport = require('./bl.js');
// var iotfClient = require('./iotfClient.js');
var apiExport = require('./api/api.js');
var wfconfig = require('./config.js');
wfconfig.loadRootConfigFile();


// This file replaces some functionallity above
var loadPrivateFunctionsFile = function() {
    try {
        // Located in the root
        //var fs = require('fs');
        var funcFileFolderPath = require('path').dirname(process.argv[1]);
        var funcFilePath = funcFileFolderPath + '/functionsoverride.js';

        // If no exception - file exists
        //fs.accessSync(funcFilePath, fs.F_OK);

        // Try to load the file only if we are on dev mode. otherwise the file won't be present (cfignore)
        fs = require('fs');
        var content = fs.readFileSync(funcFilePath, "utf8");
        eval(content);
        console.log("Functions file was loaded");

    } catch (e) {
        console.log("No functions file was found");
    }
};

// This file replaces some functionallity above
loadPrivateFunctionsFile();

module.exports = {};
module.exports.bl = blExport;
module.exports.basedal = require("./cloudant-dal/base.dal.js");
module.exports.api = apiExport;
module.exports.utils = utilExport;
module.exports.credentials = credExport;
// module.exports.iotfClient = iotfClient;

blExport.loadbls();
