/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var exec = require('child_process').exec;
var config = require('./config.js');
var path = require('path');
var fs = require('fs');

var cred = {};

// Loading credentials only if we are locally
if (process.env.VCAP_SERVICES === undefined && GLOBAL.credentials === undefined) {
    if (process.env.WF_DEPLOY_TARGET_PREFIX !== undefined) {
        console.log("credentials setup found WF_DEPLOY_TARGET_PREFIX env");
        var prefix = process.env.WF_DEPLOY_TARGET_PREFIX;
        config.populateGlobalCredentialsFromServerSync(prefix + "-api");

    } else if (process.env.WF_DEPLOY_DIRECT_TARGET_PREFIX !== undefined) {
        console.log("credentials setup found WF_DEPLOY_DIRECT_TARGET_PREFIX env");
        var target = process.env.WF_DEPLOY_DIRECT_TARGET_PREFIX;
        config.populateGlobalCredentialsFromServerSync(target);
    } else {
        console.log("credentials setup reading GLOBAL from file");

        var fs = require('fs');
        var credFileFolderPath = require('path').dirname(process.argv[1]);
        var credFilePath = credFileFolderPath + '/credentials.json';

        // If no exception - file exists
        var exists = fs.existsSync(credFilePath);
        if (exists) {
            // Try to load the file only if we are on dev mode. otherwise the file won't be present (cfignore)
            var credFile = require(credFilePath);
            var selected = credFile.current;
            var credentials = credFile.environments[selected];

            if (credentials.warning) {
                console.log("You are working locally and connected to " + selected);
                console.log("This environment has been flagged with a warning. ");
                var readlineSync = require('readline-sync');
                var answer = readlineSync.question('do you wish to continue? (y/n)');

                if (answer !== "y") {
                    process.exit(1);
                }
            }

            GLOBAL.credentials = credentials;
        } else {
            console.log("Credentials file not exists in folder " + credFileFolderPath);
            process.exit(1);
        }
    }
} else {
    console.log("credentials setup found either VCAP_SERVICES or GLOBAL env");
}

// Use override configuration
if (process.env.WF_CONFIG_OVERRIDE) {
    var overridefile = path.resolve(process.env.WF_CONFIG_OVERRIDE);
    if (fs.existsSync(overridefile)) {
        var overrideCred = require(overridefile);
        console.log("credentials OVER_RIDE found - " + overridefile);
        var overrideKeys = Object.keys(overrideCred);

        // Get the loaded existing credentials
        var targetCreds;
        if (process && process.env && process.env.VCAP_SERVICES) {
            targetCreds = JSON.parse(process.env.VCAP_SERVICES);
        } else {
            targetCreds = GLOBAL.credentials;
        }

        // Do the override
        overrideKeys.forEach(function (serviceNameKey) {
            if (process && process.env && process.env.VCAP_SERVICES) {
                targetCreds[serviceNameKey][0].credentials = overrideCred[serviceNameKey];
            } else {
                targetCreds[serviceNameKey] = overrideCred[serviceNameKey];
            }
        });


        if (process && process.env && process.env.VCAP_SERVICES) {
            process.env.VCAP_SERVICES = JSON.stringify(targetCreds);
        }
    }
}

function mergeMetrics(userMetrics, payloadMetrics) {
    var arr = Object.keys(payloadMetrics).map(function (key) {
        return payloadMetrics[key];
    });

    arr.forEach(function (candidate) {
        var existing = false;
        for (var i = 0; i < userMetrics.length; ++i) {
            if (candidate.title == userMetrics[i].title) {
                userMetrics[i].level = candidate.level;
                existing = true;
            }
        }
        if (!existing) {
            userMetrics.push(candidate);
        }
    });
}


cred.getCredentialsByServiceName = function (serviceName) {
    var credentials;

    if (process && process.env && process.env.VCAP_SERVICES) {
        var vcap_services = JSON.parse(process.env.VCAP_SERVICES);

        if (vcap_services && vcap_services[serviceName]) {
            credentials = vcap_services[serviceName][0].credentials;
        }
    } else {
        credentials = GLOBAL.credentials[serviceName];
    }

    return (credentials);
};

cred.getEnvURL = function () {
    var url;
    if (process && process.env && process.env.VCAP_APPLICATION) {
        url = process.env.APIDOMAIN;

    } else {
        url = GLOBAL.credentials.currentURL;
    }

    return (url);
};


module.exports = cred;
