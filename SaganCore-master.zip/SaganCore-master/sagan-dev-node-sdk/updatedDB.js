/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var db = require('./db.js');

/**
 * Updates the users db to replace plain text passwords with their hashed values.  
 * 
 */
function updatePasswords() {

    var usersdb = db.getDB("users");
    db.getAllUsers(function(err, doc) {
        doc.rows.forEach(function(user) {
            if (user.doc.password) {
                user.doc.password = db.hashPasswordWithSalt(user.doc.password, user.id);

                usersdb.insert(user.doc, user.id, function(err, response) {
                    if (err) {
                        console.dir(err);
                    } else {
                        console.log("Succesfully updated user " + user.id);
                    }
                });
            }
        });
    });
}

updatePasswords();