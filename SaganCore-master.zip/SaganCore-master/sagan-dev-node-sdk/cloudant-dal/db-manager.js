/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var bl = require('../index.js').bl;
var config = require('../config.js');
var wfconfig = config.loadRootConfigFile();
var fs = require('fs');
var path = require('path');
var asyncRunner = require('async');


var dbMgr = {};
module.exports = dbMgr;

// Adding wearable-framework design docs
var dalPaths = [];
dalPaths.push(__dirname);

// Adding project-specific design docs
if (wfconfig.dataaccess && wfconfig.dataaccess.path) {
    dalPaths = dalPaths.concat(wfconfig.dataaccess.path);
}

var ddPostfix = "/design-docs/";

var getDesignDocsByDBName = function(dbName) {
    var designDocs = [];

    var ddPath;

    dalPaths.forEach(function(dalpath) {
        ddPath = path.join(dalpath, ddPostfix, dbName + ".json");
        ddPath = path.resolve(ddPath);
        designDocs = designDocs.concat(getDesignDocsFromFilePath(ddPath));
    });

    return (designDocs);
};

var getDesignDocsFromFilePath = function(ddFilePath) {
    var exists = fs.existsSync(ddFilePath);
    var designDocs = [];

    if (!exists) {
        console.log("WARNING " +
            "module = db-manager, " +
            "function = getDesignDocsByDBName, " +
            "path = " + ddFilePath + ", " +
            "Message = missing desing-doc file");
    } else {
        var dd = require(ddFilePath);
        designDocs = designDocs.concat(dd);
        console.log("INFO " +
            "module = db-manager, " +
            "function = getDesignDocsByDBName, " +
            "path = " + ddFilePath + ", " +
            "Message = desing-doc loaded");
    }

    return (designDocs);
};

dbMgr.createAll = function(callback) {
    var bls = Object.keys(bl);
    var tasks = [];

    bls.forEach(function(blName) {
        var theBlName = blName;
        tasks.push(function(asyncCallback) {
            dbMgr.create(theBlName, asyncCallback);
        });
    });

    asyncRunner.series(tasks, function(err, results) {
        if (err) {
            console.log("ERROR " +
                "module = db-manager, " +
                "function = createAll, " +
                "error = " + JSON.stringify(err) + ", " +
                "Message = DB creation failed");
            callback(err, null);
        } else {
            console.log("INFO " +
                "module = db-manager, " +
                "function = createAll, " +
                "Message = DB creation succeeded");
            callback(null, results);
        }
    });
};

dbMgr.create = function(dbName, callback) {
    if (!bl[dbName]) {
        var error = "entity does not exist in BL list";
        console.log("ERROR " +
            "module = db-manager, " +
            "function = delete, " +
            "dbname = " + dbName + ", " +
            "error = " + error + ", " +
            "Message = DB deletion error");
        if (callback) {
            callback(error, null);
        }
    } else {
        var currDAL = bl[dbName].dal; //Not all entities in the business-logic folder has DALs (base.bl etc...)
        if (currDAL) {
            dbMgr.delete(dbName, function(err, result) {
                if (err) {
                    console.log("ERROR " +
                        "module = db-manager, " +
                        "function = create, " +
                        "dbname = " + dbName + ", " +
                        "error = " + JSON.stringify(err) + ", " +
                        "Message = DB deletion failed");
                    if (callback) {
                        callback(err, null);
                    }
                } else {
                    console.log("INFO " +
                        "module = db-manager, " +
                        "function = create, " +
                        "dbname = " + dbName + ", " +
                        "Message = DB deletion succeeded");
                    currDAL.createDB(function(err2, result2) {
                        if (err2) {
                            console.log("ERROR " +
                                "module = db-manager, " +
                                "function = create, " +
                                "dbname = " + dbName + ", " +
                                "error = " + JSON.stringify(err2) + ", " +
                                "Message = DB creation failed");
                            if (callback) {
                                callback(err2, null);
                            }
                        } else {
                            console.log("INFO " +
                                "module = db-manager, " +
                                "function = create, " +
                                "dbname = " + dbName + ", " +
                                "Message = DB created");

                            var dd = getDesignDocsByDBName(dbName);
                            if (dd.length > 0) {
                                setTimeout(currDAL.insertBulk(dd, function(err3, result3) {
                                    if (err3) {
                                        console.log("ERROR " +
                                            "module = db-manager, " +
                                            "function = create, " +
                                            "dbname = " + dbName + ", " +
                                            "error = " + JSON.stringify(err3) + ", " +
                                            "Message = desing-doc population failed");
                                        if (callback) {
                                            callback(err3, null);
                                        }
                                    } else {
                                        console.log("INFO " +
                                            "module = db-manager, " +
                                            "function = create, " +
                                            "dbname = " + dbName + ", " +
                                            "Message = desing-doc populated");
                                        if (callback) {
                                            callback(null, result3);
                                        }
                                    }
                                }), 3000);
                            } else {
                                if (callback) {
                                    callback(null, result2);
                                }
                            }
                        }
                    });
                }
            });
        } else {
            callback(null,{'ok':true});
        }
    }
};

dbMgr.loadFileData = function(filePath, context, callback) {

    var realFilePath = path.resolve(config.rootDir, filePath);
    var exists = fs.existsSync(realFilePath);
    if (!exists) {
        console.log("WARNING " +
            "module = db-manager, " +
            "function = loadFileData, " +
            "context = " + context + ", " +
            "filePath = " + filePath + ", " +
            "realFilePath = " + realFilePath + ", " +
            "Message = missing data file");

        realFilePath = path.resolve(filePath);
        exists = fs.existsSync(realFilePath);
    }

    if (!exists) {
        console.log("WARNING " +
            "module = db-manager, " +
            "function = loadFileData, " +
            "context = " + context + ", " +
            "filePath = " + filePath + ", " +
            "realFilePath = " + realFilePath + ", " +
            "Message = missing data file");
        callback("Missing data file - " + realFilePath, null);
    } else {
        var fileData = require(realFilePath);

        var docs = [];
        if (context) {
            docs = fileData[context];
        } else {
            var keys = Object.keys(fileData);
            keys.forEach(function(key) {
                var currContext = fileData[key];
                docs = docs.concat(currContext);
            });
        }


        var tasks = [];

        docs.forEach(function(doc) {
            doc.data.forEach(function(dataDoc) {
                var docToInsert = prepareDoc(dataDoc);
                tasks.push(function(asyncCallback) {
                    bl[doc.dbname].insert(docToInsert, function(err, result) {
                        asyncCallback(err, result);
                    });
                });
            });
        });

        asyncRunner.parallel(tasks, function(err, results) {
            if (err) {
                console.log("ERROR " +
                    "module = db-manager, " +
                    "function = loadFileData, " +
                    "context = " + context + ", " +
                    "filePath = " + filePath + ", " +
                    "realFilePath = " + realFilePath + ", " +
                    "error = " + JSON.stringify(err) + ", " +
                    "Message = Data file load failed");
                callback(err, null);
            } else {
                console.log("INFO " +
                    "module = db-manager, " +
                    "function = loadFileData, " +
                    "context = " + context + ", " +
                    "filePath = " + filePath + ", " +
                    "realFilePath = " + realFilePath + ", " +
                    "Message = Data file load succeeded");
                callback(null, results);
            }
        });
    }
};

var prepareDoc = function(doc) {
    var stringedDoc = JSON.stringify(doc);
    stringedDoc = replaceAllEnv(stringedDoc);
    return JSON.parse(stringedDoc);
};

dbMgr.loadDirData = function(dirPath, context, callback) {
    var realDirPath = path.resolve(config.rootDir, dirPath);
    var exists = fs.existsSync(realDirPath);
    if (!exists) {
        console.log("WARNING " +
            "module = db-manager, " +
            "function = loadDirData, " +
            "context = " + context + ", " +
            "dirPath = " + dirPath + ", " +
            "realDirPath = " + realDirPath + ", " +
            "Message = missing data file");

        realDirPath = path.resolve(dirPath);
        exists = fs.existsSync(realDirPath);
    }

    if (!exists) {
        console.log("WARNING " +
            "module = db-manager, " +
            "function = loadDirData, " +
            "context = " + context + ", " +
            "dirPath = " + dirPath + ", " +
            "realDirPath = " + realDirPath + ", " +
            "Message = missing data file");
    } else {

        files = fs.readdirSync(realDirPath);

        files = files.filter(function(file) {
            return file.indexOf(".json", 0) !== -1;
        });

        files.forEach(function(fileName) {
            dbMgr.loadFileData(path.resolve(realDirPath, fileName), context, callback);
        });
    }
};

dbMgr.deleteAll = function(callback) {
    var bls = Object.keys(bl);
    var tasks = [];

    bls.forEach(function(blName) {
        var theBlName = blName;
        tasks.push(function(asynccallback) {
            dbMgr.delete(theBlName, function(err, result) {
                // doing nothing
                asynccallback(err, result);
            });
        });
    });

    asyncRunner.parallel(tasks, function(err, results) {
        if (err) {
            console.log("ERROR " +
                "module = db-manager, " +
                "function = deleteAll, " +
                "error = " + JSON.stringify(err) + ", " +
                "Message = DB deletion failed");
            callback(err, null);
        } else {
            console.log("INFO " +
                "module = db-manager, " +
                "function = deleteAll, " +
                "Message = DB deletion succeeded");
            callback(null, results);
        }
    });
};

dbMgr.delete = function(dbName, callback) {
    if (!bl[dbName]) {
        var error = "entity does not exist in BL list";
        console.log("ERROR " +
            "module = db-manager, " +
            "function = delete, " +
            "dbname = " + dbName + ", " +
            "error = " + error + ", " +
            "Message = DB deletion error");
        callback(error, null);
    } else {
        var currDAL = bl[dbName].dal; //Not all entities in the business-logic folder has DALs (base.bl etc...)
        if (currDAL) {
            currDAL.doesDBExist(function(err, result) {
                if (err) {
                    console.log("ERROR " +
                        "module = db-manager, " +
                        "function = delete, " +
                        "dbname = " + dbName + ", " +
                        "error = " + JSON.stringify(err) + ", " +
                        "Message = DB deletion error");
                    callback(err, null);
                } else {
                    if (result) {
                        currDAL.deleteDB(callback);
                    } else {
                        callback(null, result);
                    }
                }
            });
        } else {
            callback(null,{'ok':true});
        }
    }
};

var regexExtractAll = function(regex, string) {
    var match = null;
    var matches = [];
    while (match = regex.exec(string)) {
        var matchArray = [];
        for (var i in match) {
            if (parseInt(i) == i) {
                matchArray.push(match[i]);
            }
        }
        matches.push(matchArray);
    }
    return matches;
};

var getAllEnv = function(str) {
    var allEnv = regexExtractAll(/{\$.*?}/g, str);
    var envSet = [];
    var envArr = [];
    allEnv.forEach(function(envCandidate) {
        if (envSet.indexOf(envCandidate[0]) == -1) {
            var envName = /{\$(.*?)}/.exec(envCandidate[0]);
            envArr.push({
                name: envName[1],
                reg: envCandidate[0]
            });
            envSet.push(envCandidate[0]);
        }
    });
    return envArr;
};

var replaceAllEnv = function(str) {
    var envArr = getAllEnv(str);
    var newStr = str;
    var i = 1;
    envArr.forEach(function(elem) {
        var value = process.env[elem.name] || wfconfig.env[elem.name];
        if (value) {
            // OPTION 2: THE following
            var regex = new RegExp(elem.reg.replace(/\$/g, "\\\$"), 'g');
            newStr = newStr.replace(regex, value);

            // OPTION 3: THE following does global repalces just fine (slower 53% than regx solution)
            //newStr = newStr.split(elem.reg).join(value);
        } else {
            console.log("WARNING " +
                "module = db-manager, " +
                "function = replaceAllEnv, " +
                "context = " + JSON.stringify(elem) + ", " +
                "env = " + elem.name + ", " +
                "Message = missing definition for environment variable");
        }
    });
    return newStr;
};
