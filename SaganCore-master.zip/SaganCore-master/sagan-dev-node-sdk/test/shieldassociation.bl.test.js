/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var dbmgr = require('../cloudant-dal/db-manager.js');
var shieldAssociationBL = require('../business-logic/shieldassociation.bl.js');
var async = require('async');
var testTools = require('./testTools.js');
var path = require('path');
var dataFilePath = path.join(__dirname, "bl", "shieldassociation.json");

describe('Shield Association BL', function () {
    var docId = "";

    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        //testTools.disableLogs();

        dbmgr.create(shieldAssociationBL._name, function (err) {
            expect(err).to.be.null;
            done();
        });

    });


    afterEach(function (done) {
        dbmgr.delete(shieldAssociationBL._name, function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            done();
        });
    });

    after(function () {
    });

    var loadTestByName = function (testName, callback) {
        dbmgr.loadFileData(dataFilePath, testName, function (err, results) {
            expect(err).to.be.null;
            callback(err, results)
        });
    };

    var buildArrayWithoutDoc = function (arr) {
        var newArr = [];

        arr.forEach(function (doc) {
            newArr.push(doc.doc);
        });

        return (newArr);
    };

    describe('shieldassociation.wrapResults', function () {

        it('shieldassociation.wrapResults', function (done) {

            var docs = require(dataFilePath).wrapResultsSingleUserNoParams[0].data;

            var wrappedDocs = shieldAssociationBL.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docs);

            done();
        });

        it('shieldassociation.wrapResults with doc.doc', function (done) {

            var docs = require(dataFilePath).wrapResultsSingleUserWithDocNoParams[0].data;
            var wrappedDocs = shieldAssociationBL.wrapResults(docs);
            var docsWithoutDoc = buildArrayWithoutDoc(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docsWithoutDoc);

            done();
        });

        it('shieldassociation.wrapResults with parameters', function (done) {

            var docs = require(dataFilePath).wrapResultsSingleUserParams[0].data;

            var wrappedDocs = shieldAssociationBL.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docs);
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0]).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0].params).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0].params).not.to.be.empty;

            done();
        });

        it('shieldassociation.wrapResults multiple docs', function (done) {

            var docs = require(dataFilePath).wrapResultsMultipleUsersNoParams[0].data;

            var wrappedDocs = shieldAssociationBL.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docs);

            done();
        });

        it('shieldassociation.wrapResults multiple docs with doc.doc', function (done) {

            var docs = require(dataFilePath).wrapResultsMultipleUsersWithDoc[0].data;
            var wrappedDocs = shieldAssociationBL.wrapResults(docs);
            var docsWithoutDoc = buildArrayWithoutDoc(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docsWithoutDoc);

            done();
        });

        it('shieldassociation.wrapResults multiple docs with parameters', function (done) {

            var docs = require(dataFilePath).wrapResultsMultipleUsersParams[0].data;

            var wrappedDocs = shieldAssociationBL.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.empty;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.have.members(docs);
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0]).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0].params).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's'][0].params).not.to.be.empty;

            done();
        });

        it('shieldassociation.wrapResults no docs', function (done) {
            var docs = [];

            var wrappedDocs = shieldAssociationBL.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.be.empty;

            done();
        });

        it('shieldassociation.wrapResults undefined docs', function (done) {
            var wrappedDocs = shieldAssociationBL.wrapResults(undefined);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(0);

            expect(wrappedDocs[shieldAssociationBL._name + 's']).not.to.be.null;
            expect(wrappedDocs[shieldAssociationBL._name + 's']).to.be.empty;

            done();
        });
    });

    describe('shieldassociation.getUserShieldAssociations', function () {

        it('shieldassociation.getUserShieldAssociations', function (done) {
            var testName = "getUserShieldAssociationsSingleUserSingleDoc";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations("test", function (err, selectedDocs) {
                    var docs = require(dataFilePath)[testName][0].data;

                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).not.to.be.empty;
                    expect(selectedDocs.length).to.be.equal(docs.length);

                    var cleanSelectedDocs = testTools.removeIdAndRev(selectedDocs);
                    expect(cleanSelectedDocs).to.deep.include.members(docs);
                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations single user with parameters', function (done) {

            var testName = "getUserShieldAssociationsSingleUserParams";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations("dyw.emp", function (err, selectedDocs) {
                    var docs = require(dataFilePath)[testName][0].data;

                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).not.to.be.empty;
                    expect(selectedDocs.length).to.be.equal(docs.length);

                    var cleanSelectedDocs = testTools.removeIdAndRev(selectedDocs);
                    expect(cleanSelectedDocs).to.deep.include.members(docs);
                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations multiple users no parameters same user', function (done) {

            var testName = "getUserShieldAssociationsMultipleUsersNoParamSameUser";
            var username = "test1";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations(username, function (err, selectedDocs) {
                    var docs = require(dataFilePath)[testName][0].data;

                    var doc = docs.find(function findElement(element) {
                        return element.username === username;
                    });

                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).not.to.be.empty;
                    expect(selectedDocs.length).to.be.equal(docs.length);

                    var cleanSelectedDocs = testTools.removeIdAndRev(selectedDocs);
                    expect(cleanSelectedDocs).to.deep.include.members([doc]);
                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations multiple users no parameters different users', function (done) {

            var testName = "getUserShieldAssociationsMultipleUsersNoParamsDifferentUsers";
            var username = "test1";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations(username, function (err, selectedDocs) {
                    var docs = require(dataFilePath)[testName][0].data;

                    var doc = docs.find(function findElement(element) {
                        return element.username === username;
                    });

                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).not.to.be.empty;
                    expect(selectedDocs.length).to.be.equal(1);

                    var cleanSelectedDocs = testTools.removeIdAndRev(selectedDocs);
                    expect(cleanSelectedDocs).to.deep.include.members([doc]);
                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations multiple users with parameters single users', function (done) {

            var testName = "getUserShieldAssociationsMultipleUsersWithParamsSingleUser";
            var username = "dyw.emp2";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations(username, function (err, selectedDocs) {
                    var docs = require(dataFilePath)[testName][0].data;

                    var doc = docs.find(function findElement(element) {
                        return element.username === username;
                    });

                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).not.to.be.empty;
                    expect(selectedDocs.length).to.be.equal(1);

                    var cleanSelectedDocs = testTools.removeIdAndRev(selectedDocs);
                    expect(cleanSelectedDocs).to.deep.include.members([doc]);
                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations wrong user no docs', function (done) {

            var testName = "getUserShieldAssociationsMultipleUsersWithParamsSingleUser";
            var username = "asdfasdf";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                shieldAssociationBL.getUserShieldAssociations(username, function (err, selectedDocs) {
                    expect(err).to.be.null;
                    expect(selectedDocs).not.to.be.null;
                    expect(selectedDocs).to.be.empty;

                    done();
                });
            });
        });

        it('shieldassociation.getUserShieldAssociations no docs', function (done) {
            var username = "asdfasdf";

            shieldAssociationBL.getUserShieldAssociations(username, function (err, selectedDocs) {
                expect(err).to.be.null;
                expect(selectedDocs).not.to.be.null;
                expect(selectedDocs).to.be.empty;

                done();
            });
        });
    });

    describe('shieldassociation.updateShieldAssociationOnCloud', function () {

        it('shieldassociation.updateShieldAssociationOnCloud existing field', function (done) {
            var testName = "updateShieldAssociationOnCloudExistingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                shieldAssociationBL.updateShieldAssociationOnCloud(insertedDoc.id, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    shieldAssociationBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.hazardDetectionOnCloud).to.be.false;

                        done();
                    });
                });
            });
        });

        it('shieldassociation.updateShieldAssociationOnCloud existing field same value', function (done) {
            var testName = "updateShieldAssociationOnCloudExistingFieldSameValue";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                shieldAssociationBL.updateShieldAssociationOnCloud(insertedDoc.id, true, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result).to.be.false;

                    shieldAssociationBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.hazardDetectionOnCloud).to.be.true;

                        done();
                    });
                });
            });
        });

        it('shieldassociation.updateShieldAssociationOnCloud adding field', function (done) {
            var testName = "updateShieldAssociationOnCloudAddingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                shieldAssociationBL.updateShieldAssociationOnCloud(insertedDoc.id, false, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    shieldAssociationBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.hazardDetectionOnCloud).to.be.false;

                        done();
                    });
                });
            });
        });

        it('shieldassociation.updateShieldAssociationOnCloud removing field', function (done) {
            var testName = "updateShieldAssociationOnCloudRemovingField";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                shieldAssociationBL.updateShieldAssociationOnCloud(insertedDoc.id, undefined, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).not.to.be.null;
                    expect(result.ok).to.be.true;
                    expect(result.id).to.be.equal(insertedDoc.id);

                    shieldAssociationBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.hazardDetectionOnCloud).not.to.be.exist;

                        done();
                    });
                });
            });
        });

        it('shieldassociation.updateShieldAssociationOnCloud missing id', function (done) {
            var testName = "updateShieldAssociationOnCloudMissingID";
            loadTestByName(testName, function (err, result) {

                expect(err).to.be.null;
                expect(result).not.to.be.null;

                var insertedDoc = result[0];

                shieldAssociationBL.updateShieldAssociationOnCloud(undefined, true, function (err, result) {
                    expect(err).not.to.be.null;

                    shieldAssociationBL.getByID(insertedDoc.id, function (err, selectedDoc) {
                        expect(err).to.be.null;
                        expect(selectedDoc).not.to.be.null;
                        expect(selectedDoc).not.to.be.empty;
                        expect(selectedDoc.hazardDetectionOnCloud).to.be.true;

                        done();
                    });
                });
            });
        });
    });
});
