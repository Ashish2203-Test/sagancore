/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


var expect = require("chai").expect;
var chance = require('chance');
var baseBL = require('../business-logic/base.bl.js');
var async = require('async');
var testTools = require('./testTools.js');

describe('Base BL', function () {
    var bl = {};
    var dbName = "";
    var entityName = "";
    var docId = "";


    this.timeout(60000);

    before(function () {


    });

    beforeEach(function (done) {

        docId = "id" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 14});
        dbName = "test" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 6});
        entityName = "entity" + new chance.Chance().string({pool: "abcdefghijklmnopqrstuvwxyz1234567890", length: 6});
        //testTools.disableLogs();
        bl = new baseBL('base');
        bl._name = entityName;

        bl.dal = new bl.dal(dbName); // Base BL does not auto-instantiate its DAL
        bl.dal.createDB(function (err) {
            expect(err).to.be.null;
            done();
        });

    });


    afterEach(function (done) {
        bl.dal.deleteDB(function (err) {
            testTools.enableLogs();
            expect(err).to.be.null;
            done();
        });
    });

    after(function () {
    });

    describe('BaseBL.wrapResults', function () {

        it('BaseBL.wrapResults', function (done) {
            var docs = [];
            for (var index = 0; index < 10; index++) {
                docs.push({docID: docId, index: index});
            }
            ;

            var wrappedDocs = bl.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[entityName + 's']).not.to.be.null;
            expect(wrappedDocs[entityName + 's']).not.to.be.empty;
            expect(wrappedDocs[entityName + 's']).to.have.members(docs);

            done();
        });

        it('BaseBL.wrapResults with doc.rows', function (done) {
            var docs = {};
            docs.rows = [];
            for (var index = 0; index < 10; index++) {
                docs.rows.push({docID: docId, index: index});
            }
            ;

            var wrappedDocs = bl.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.rows.length);

            expect(wrappedDocs[entityName + 's']).not.to.be.null;
            expect(wrappedDocs[entityName + 's']).not.to.be.empty;
            expect(wrappedDocs[entityName + 's']).to.have.members(docs.rows);

            done();
        });

        it('BaseBL.wrapResults no docs', function (done) {
            var docs = [];

            var wrappedDocs = bl.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.length);

            expect(wrappedDocs[entityName + 's']).not.to.be.null;
            expect(wrappedDocs[entityName + 's']).to.be.empty;

            done();
        });

        it('BaseBL.wrapResults undefined docs', function (done) {
            var wrappedDocs = bl.wrapResults(undefined);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(0);

            expect(wrappedDocs[entityName + 's']).not.to.be.null;
            expect(wrappedDocs[entityName + 's']).to.be.empty;

            done();
        });

        it('BaseBL.wrapResults with doc.rows no docs', function (done) {
            var docs = [];
            docs.rows = [];

            var wrappedDocs = bl.wrapResults(docs);

            expect(wrappedDocs).not.to.be.null;
            expect(wrappedDocs).not.to.be.empty;
            expect(wrappedDocs.total).not.to.be.null;
            expect(wrappedDocs.total).to.be.equal(docs.rows.length);

            expect(wrappedDocs[entityName + 's']).not.to.be.null;
            expect(wrappedDocs[entityName + 's']).to.be.empty;

            done();
        });
    });

    describe('BaseBL.getByID', function () {
        it('BaseBL.getByID success', function (done) {
            bl.dal.insert({docID: docId}, function (err, result) {
                expect(err).to.be.null;

                bl.getByID(result.id, function (err, doc) {
                    expect(err).to.be.null;
                    expect(doc).not.to.be.null;
                    expect(doc).not.to.be.empty;
                    expect(doc.docID).to.be.equal(docId);

                    done();
                })
            });
        });

        it('BaseBL.getByID fail', function (done) {
            bl.getByID(docId, function (err, doc) {
                expect(err).not.to.be.null;
                expect(doc).to.be.null;

                done();
            })
        });
    });

    describe('BaseBL.insert', function () {

        it('BaseBL:insert', function (done) {

            var newDoc = {'testID': docId};

            // Insert Entity
            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                //Check if selected entity matches the inserted entity
                bl.getByID(result.id, function (err, doc) {
                    expect(err).to.be.null;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(docId);
                    done();
                });
            });
        });
    });

    describe('BaseBL.insertBulk', function () {

        it('BaseBL.insertBulk multiple docs', function (done) {

            var calls = [];

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"}, {'testID': docId + "2", 'idIndex': '2'}];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(newDocs.length);

                result.forEach(function (resultDoc) {
                    calls.push(function (asyncCallback) {
                        bl.getByID(resultDoc.id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');

                            var docIdIndex = docId + doc.idIndex;
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });
                    });
                });

                async.parallel(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.insertBulk single doc', function (done) {

            var calls = [];

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"}];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(newDocs.length);

                result.forEach(function (resultDoc) {
                    calls.push(function (asyncCallback) {
                        bl.getByID(resultDoc.id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');

                            var docIdIndex = docId + doc.idIndex;
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });
                    });
                });

                async.parallel(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.insertBulk no docs', function (done) {

            var calls = [];

            var newDocs = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).to.be.empty;
                expect(result.length).to.be.equal(newDocs.length);

                result.forEach(function (resultDoc) {
                    calls.push(function (asyncCallback) {
                        bl.getByID(resultDoc.id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.idIndex).to.exist;
                            expect(doc.idIndex).not.to.be.empty;
                            expect(doc.idIndex).to.be.a('string');

                            var docIdIndex = docId + doc.idIndex;
                            expect(doc.testID).to.be.equal(docIdIndex);
                            asyncCallback(null, true);
                        });
                    });
                });

                async.parallel(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

    });

    describe('BaseBL.update', function () {

        it('BaseBL.update field success', function (done) {

            var doc = {'testID': docId};

            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                var id = result.id;

                bl.getByID(id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    var newDocId = "newId" + new chance.Chance().string({
                            pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                            length: 14
                        });

                    getDoc.testID = newDocId;

                    bl.update(getDoc, function (err, result) {
                        expect(err).to.be.null;

                        bl.getByID(id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(newDocId);
                            done();
                        });
                    });
                });
            });
        });

        it('BaseBL.update field success (add new field)', function (done) {

            var doc = {'testID': docId};

            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                var id = result.id;

                bl.getByID(id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    var newDocId = "newId" + new chance.Chance().string({
                            pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                            length: 14
                        });

                    getDoc.newField = newDocId;

                    bl.update(getDoc, function (err, result) {
                        expect(err).to.be.null;

                        bl.getByID(id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docId);

                            expect(doc.newField).to.exist;
                            expect(doc.newField).not.to.be.empty;
                            expect(doc.newField).to.be.a('string');
                            expect(doc.newField).to.be.equal(newDocId);
                            done();
                        });
                    });
                });
            });
        });

        it('BaseDAL:Update field success (remove existing field)', function (done) {


            var newDocId = "newId" + new chance.Chance().string({
                    pool: "abcdefghijklmnopqrstuvwxyz1234567890",
                    length: 14
                });
            var doc = {'testID': docId, 'newTestID': newDocId};

            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                var id = result.id;

                bl.getByID(id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;

                    delete getDoc.newTestID;

                    bl.update(getDoc, function (err, result) {
                        expect(err).to.be.null;

                        bl.getByID(id, function (err, doc) {
                            expect(err).to.be.null;
                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docId);

                            expect(doc.newTestID).not.to.exist;
                            done();
                        });
                    });
                });
            });
        });
    });

    describe('BaseBL.getAll', function () {

        it('BaseBL.getAll success', function (done) {
            var calls = [];

            var newDocs = [{'testID': docId + "1", 'idIndex': "1",},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"}];

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).not.to.be.empty;

                bl.getAll(function (err, docs) {
                    expect(err).to.be.null;
                    expect(docs).to.be.a('array');
                    expect(docs).not.to.be.empty;
                    expect(docs.count).to.be.equal(newDocs.count);


                    insertResult.forEach(function (resultDoc) {
                        calls.push(function (asyncCallback) {

                            bl.getByID(resultDoc.id, function (err, getDoc) {
                                expect(err).to.be.null;
                                expect(getDoc).not.to.be.null;

                                var doc = docs.find(function findElement(element) {
                                    return element.testID === getDoc.testID;
                                });

                                expect(doc).not.to.be.null;
                                console.log(JSON.stringify(doc));

                                if (doc) {
                                    expect(doc.testID).to.exist;
                                    expect(doc.testID).not.to.be.empty;
                                    expect(doc.testID).to.be.a('string');
                                    expect(doc.testID).to.be.equal(getDoc.testID);
                                    expect(doc.idIndex).to.exist;
                                    expect(doc.idIndex).not.to.be.empty;
                                    expect(doc.idIndex).to.be.a('string');
                                }
                            });

                            asyncCallback(null, true);
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });
                });
            });
        });

        it('BaseBL.getAll no docs', function (done) {
            var newDocs = [];

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).to.be.empty;

                bl.getAll(function (err, docs) {
                    expect(err).to.be.null;
                    expect(docs).to.be.a('array');
                    expect(docs).to.be.empty;
                    expect(docs.count).to.be.equal(newDocs.count);

                    done();
                });
            });
        });
    });

    describe('BaseBL.getAllPaginated', function () {
        it('BaseBL.getAllPaginated 2 complete pages', function (done) {

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"},
                {'testID': docId + "4", 'idIndex': "4"}];

            var count = newDocs.length;
            var limit = 2;
            var calls = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                var paginatedDocs = [];

                // Skip = Number of rows to skip, look inside at index
                for (var skip = 0; skip < count; skip += limit) {
                    (function (index) {
                        calls.push(function (asyncCallback) {
                            bl.getAllPaginated(limit, index, function (err, docs) {
                                expect(err).to.be.null;
                                expect(docs).not.to.be.empty;
                                expect(docs.rows).to.be.exist;
                                expect(docs.rows).to.be.a('array');
                                expect(docs.rows.length).to.be.at.most(limit);
                                paginatedDocs = paginatedDocs.concat(docs.rows);
                                asyncCallback(null, true);
                            })
                        })
                    })(skip);
                }

                calls.push(function (asyncCallback) {
                    expect(paginatedDocs).not.to.be.empty;
                    expect(paginatedDocs).to.be.a('array');
                    expect(paginatedDocs.length).to.be.equal(count);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[0];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[1];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[2];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[3];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.getAllPaginated 2 incomplete pages', function (done) {

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"}];

            var count = newDocs.length;
            var limit = 2;
            var calls = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                var paginatedDocs = [];

                // Skip = Number of rows to skip, look inside at index
                for (var skip = 0; skip < count; skip += limit) {
                    (function (index) {
                        calls.push(function (asyncCallback) {
                            bl.getAllPaginated(limit, index, function (err, docs) {
                                expect(err).to.be.null;
                                expect(docs).not.to.be.empty;
                                expect(docs.rows).to.be.exist;
                                expect(docs.rows).to.be.a('array');
                                expect(docs.rows.length).to.be.at.most(limit);
                                paginatedDocs = paginatedDocs.concat(docs.rows);
                                asyncCallback(null, true);
                            })
                        })
                    })(skip);
                }

                calls.push(function (asyncCallback) {
                    expect(paginatedDocs).not.to.be.empty;
                    expect(paginatedDocs).to.be.a('array');
                    expect(paginatedDocs.length).to.be.equal(count);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[0];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[1];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[2];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.getAllPaginated count = limit (all docs)', function (done) {

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"},
                {'testID': docId + "4", 'idIndex': "4"}];

            var count = newDocs.length;
            var limit = count;
            var calls = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                var paginatedDocs = [];

                // Skip = Number of rows to skip, look inside at index
                for (var skip = 0; skip < count; skip += limit) {
                    (function (index) {
                        calls.push(function (asyncCallback) {
                            bl.getAllPaginated(limit, index, function (err, docs) {
                                expect(err).to.be.null;
                                expect(docs).not.to.be.empty;
                                expect(docs.rows).to.be.exist;
                                expect(docs.rows).to.be.a('array');
                                expect(docs.rows.length).to.be.at.most(limit);
                                paginatedDocs = paginatedDocs.concat(docs.rows);
                                asyncCallback(null, true);
                            })
                        })
                    })(skip);
                }

                calls.push(function (asyncCallback) {
                    expect(paginatedDocs).not.to.be.empty;
                    expect(paginatedDocs).to.be.a('array');
                    expect(paginatedDocs.length).to.be.equal(count);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[0];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[1];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[2];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[3];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.getAllPaginated count < limit (all docs)', function (done) {

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"},
                {'testID': docId + "4", 'idIndex': "4"}];

            var count = newDocs.length;
            var limit = count + 1;
            var calls = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                var paginatedDocs = [];

                // Skip = Number of rows to skip, look inside at index
                for (var skip = 0; skip < count; skip += limit) {
                    (function (index) {
                        calls.push(function (asyncCallback) {
                            bl.getAllPaginated(limit, index, function (err, docs) {
                                expect(err).to.be.null;
                                expect(docs).not.to.be.empty;
                                expect(docs.rows).to.be.exist;
                                expect(docs.rows).to.be.a('array');
                                expect(docs.rows.length).to.be.at.most(limit);
                                paginatedDocs = paginatedDocs.concat(docs.rows);
                                asyncCallback(null, true);
                            })
                        })
                    })(skip);
                }

                calls.push(function (asyncCallback) {
                    expect(paginatedDocs).not.to.be.empty;
                    expect(paginatedDocs).to.be.a('array');
                    expect(paginatedDocs.length).to.be.equal(count);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[0];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[1];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;

                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[2];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[3];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });

        it('BaseBL.getAllPaginated partial docs (half)', function (done) {

            var newDocs = [{'testID': docId + "1", 'idIndex': "1"},
                {'testID': docId + "2", 'idIndex': "2"},
                {'testID': docId + "3", 'idIndex': "3"},
                {'testID': docId + "4", 'idIndex': "4"}];

            var count = newDocs.length / 2;
            var limit = count;
            var calls = [];

            bl.insertBulk(newDocs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                var paginatedDocs = [];

                // Skip = Number of rows to skip, look inside at index
                for (var skip = 0; skip < count; skip += limit) {
                    (function (index) {
                        calls.push(function (asyncCallback) {
                            bl.getAllPaginated(limit, index, function (err, docs) {
                                expect(err).to.be.null;
                                expect(docs).not.to.be.empty;
                                expect(docs.rows).to.be.exist;
                                expect(docs.rows).to.be.a('array');
                                expect(docs.rows.length).to.be.at.most(limit);
                                paginatedDocs = paginatedDocs.concat(docs.rows);
                                asyncCallback(null, true);
                            })
                        })
                    })(skip);
                }

                calls.push(function (asyncCallback) {
                    expect(paginatedDocs).not.to.be.empty;
                    expect(paginatedDocs).to.be.a('array');
                    expect(paginatedDocs.length).to.be.equal(count);
                    asyncCallback(null, true);
                });

                // calls.push(function (asyncCallback) {
                //     var checkDoc = newDocs[0];
                //     var doc = paginatedDocs.find(function findElement(element) {
                //         return element.doc.testID === checkDoc.testID;
                //     }).doc;
                //
                //     expect(doc).not.to.be.undefined;
                //     expect(doc.testID).to.exist;
                //     expect(doc.testID).not.to.be.empty;
                //     expect(doc.testID).to.be.a('string');
                //     expect(doc.testID).to.be.equal(checkDoc.testID);
                //     expect(doc.idIndex).to.exist;
                //     expect(doc.idIndex).not.to.be.empty;
                //     expect(doc.idIndex).to.be.a('string');
                //     expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                //     asyncCallback(null, true);
                // });
                //
                // calls.push(function (asyncCallback) {
                //     var checkDoc = newDocs[1];
                //     var doc = paginatedDocs.find(function findElement(element) {
                //         return element.doc.testID === checkDoc.testID;
                //     }).doc;
                //
                //     expect(doc).not.to.be.undefined;
                //     expect(doc.testID).to.exist;
                //     expect(doc.testID).not.to.be.empty;
                //     expect(doc.testID).to.be.a('string');
                //     expect(doc.testID).to.be.equal(checkDoc.testID);
                //     expect(doc.idIndex).to.exist;
                //     expect(doc.idIndex).not.to.be.empty;
                //     expect(doc.idIndex).to.be.a('string');
                //     expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                //     asyncCallback(null, true);
                // });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[2];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                calls.push(function (asyncCallback) {
                    var checkDoc = newDocs[3];
                    var doc = paginatedDocs.find(function findElement(element) {
                        return element.doc.testID === checkDoc.testID;
                    }).doc;
                    expect(doc).not.to.be.undefined;
                    expect(doc.testID).to.exist;
                    expect(doc.testID).not.to.be.empty;
                    expect(doc.testID).to.be.a('string');
                    expect(doc.testID).to.be.equal(checkDoc.testID);
                    expect(doc.idIndex).to.exist;
                    expect(doc.idIndex).not.to.be.empty;
                    expect(doc.idIndex).to.be.a('string');
                    expect(doc.idIndex).to.be.equal(checkDoc.idIndex);
                    asyncCallback(null, true);
                });

                async.series(calls, function (err, result) {
                    expect(err).to.be.null;
                    done();
                });
            });
        });
    });

    describe('BaseBL.getAllByAttribute', function () {
        it('BaseBL.getAllByAttribute single doc', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getAllByAttribute("testID", docId, function (err, selectedDoc) {
                    expect(err).to.be.null;
                    expect(selectedDoc).not.to.be.null;
                    expect(selectedDoc).to.be.a('array');
                    expect(selectedDoc.length).to.be.equal(1);
                    expect(selectedDoc[0].testID).to.be.exist;
                    expect(selectedDoc[0].testID).to.be.equal(newDoc.testID);

                    done();
                });
            });
        });

        it('BaseBL.getAllByAttribute no docs (wrong value)', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getAllByAttribute("testID", docId + "1", function (err, selectedDoc) {
                    expect(err).to.be.null;
                    expect(selectedDoc).not.to.be.null;
                    expect(selectedDoc).to.be.a('array');
                    expect(selectedDoc).to.be.empty;

                    done();
                });
            });
        });

        it('BaseBL.getAllByAttribute no docs (wrong attribute)', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getAllByAttribute("asdf", docId, function (err, selectedDoc) {
                    expect(err).to.be.null;
                    expect(selectedDoc).not.to.be.null;
                    expect(selectedDoc).to.be.a('array');
                    expect(selectedDoc).to.be.empty;

                    done();
                });
            });
        });

        it('BaseBL.getAllByAttribute attribute name undefined', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getAllByAttribute(undefined, docId, function (err, selectedDoc) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Must specify attribute name');
                    expect(selectedDoc).to.be.null;

                    done();
                });
            });
        });

        it('BaseBL.getAllByAttribute attribute value undefined', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getAllByAttribute("asdf", undefined, function (err, selectedDoc) {
                    expect(err).not.to.be.null;
                    expect(err).to.be.equal('Must specify attribute value');
                    expect(selectedDoc).to.be.null;

                    done();
                });
            });
        });

        it('BaseBL.getAllByAttribute multiple docs', function (done) {
            var docs = [{'testID': docId, 'no': 1}, {'testID': docId, 'no': 2}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;

                bl.getAllByAttribute("testID", docId, function (err, selectedDoc) {
                    expect(err).to.be.null;
                    expect(selectedDoc).not.to.be.null;
                    expect(selectedDoc).to.be.a('array');
                    expect(selectedDoc.length).to.be.equal(docs.length);
                    expect(selectedDoc[0].testID).to.be.exist;
                    expect(selectedDoc[0].testID).to.be.equal(docId);
                    expect(selectedDoc[0].no).to.be.equal(1);

                    expect(selectedDoc[1].testID).to.be.exist;
                    expect(selectedDoc[1].testID).to.be.equal(docId);
                    expect(selectedDoc[1].no).to.be.equal(2);

                    done();
                });
            });
        });
    });

    describe('BaseBL.delete', function () {

        it('BaseBL.delete single doc', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;
                    expect(getDoc).not.to.be.empty;
                    expect(getDoc.testID).to.be.equal(docId);

                    bl.delete(getDoc, function (err, response) {
                        expect(err).to.be.null;

                        //CHeck if entity exists (should not)
                        bl.getByID(result.id, function (err, doc) {

                            expect(err).to.exist;
                            expect(err).not.to.be.empty;
                            expect(err.reason).to.equal('deleted');
                            done();

                        });
                    });
                })
            });
        });

        it('BaseBL.delete no doc', function (done) {

            //Deleting Entity
            bl.delete(docId, function (err, response) {
                expect(err).not.to.be.null;
                done();
            });
        });

        it('BaseBL.delete two docs delete one', function (done) {
            testTools.enableLogs();

            var newDocs = [{'testID': docId + "1", "docNo": "1"}, {'testID': docId + "2", "docNo": "2"}];

            bl.insertBulk(newDocs, function (err, resultArray) {
                expect(err).to.be.null;
                expect(resultArray).to.be.a('array');
                expect(resultArray).not.to.be.empty;
                expect(resultArray.length).to.be.equal(newDocs.length);

                bl.getByID(resultArray[0].id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;
                    expect(getDoc).not.to.be.empty;
                    expect(getDoc.testID).to.be.equal(docId + getDoc.docNo);

                    bl.delete(getDoc, function (err, response) {
                        expect(err).to.be.null;

                        //CHeck if entity exists (should not)
                        bl.getByID(resultArray[0].id, function (err, deletedDoc) {

                            expect(err).to.exist;
                            expect(err).not.to.be.empty;
                            expect(err.reason).to.equal('deleted');

                            bl.getByID(resultArray[1].id, function (err, existsDoc) {

                                expect(err).not.to.exist;
                                expect(existsDoc).not.to.be.null;
                                expect(existsDoc).not.to.be.empty;
                                expect(existsDoc.testID).to.be.equal(docId + existsDoc.docNo);
                                done();
                            });
                        });
                    });
                })
            });
        });
    });

    describe('BaseBL.deleteByID', function () {
        it('BaseBL.deleteByID ', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;
                    expect(getDoc).not.to.be.empty;
                    expect(getDoc.testID).to.be.equal(docId);

                    bl.deleteByID(result.id, function (err, response) {
                        expect(err).to.be.null;
                        expect(response.ok).to.be.true;
                        expect(response.id).to.be.equal(result.id);

                        //CHeck if entity exists (should not)
                        bl.getByID(result.id, function (err, doc) {

                            expect(err).to.exist;
                            expect(err).not.to.be.empty;
                            expect(err.reason).to.equal('deleted');
                            done();
                        });
                    });
                })
            });
        });

        it('BaseBL.deleteByID deleted doc', function (done) {
            var newDoc = {'testID': docId};

            bl.insert(newDoc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByID(result.id, function (err, getDoc) {
                    expect(err).to.be.null;
                    expect(getDoc).not.to.be.null;
                    expect(getDoc).not.to.be.empty;
                    expect(getDoc.testID).to.be.equal(docId);

                    bl.deleteByID(result.id, function (err, response) {
                        expect(err).to.be.null;

                        bl.deleteByID(result.id, function (err, response) {
                            expect(err).not.to.be.null;
                            done();
                        });
                    });
                })
            });
        });

        it('BaseBL.deleteByID non existing ID', function (done) {
            bl.deleteByID("asdf", function (err, response) {
                expect(err).not.to.be.null;
                done();
            });
        });
    });

    describe('BaseBL.deleteBulk', function () {

        it('BaseBL:deleteBulk all docs (id/rev)', function (done) {

            var newDocs = [{'testID': docId + "1", 'docNo': "1"},
                {'testID': docId + "2", 'docNo': "2"}];

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).not.to.be.empty;
                expect(insertResult.length).to.be.equal(newDocs.length);

                bl.deleteBulk(insertResult, function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;

                    var calls = [];

                    insertResult.forEach(function (resultDoc) {
                        calls.push(function (asyncCallback) {
                            bl.getByID(resultDoc.id, function (err, doc) {
                                expect(err).to.exist;
                                expect(err).not.to.be.empty;
                                expect(err.reason).to.equal('deleted');
                                asyncCallback(null, true);
                            });
                        });
                    });

                    async.parallel(calls, function (err, result) {
                        expect(err).to.be.null;
                        done();
                    });
                });
            });
        });

        it('BaseBL:deleteBulk 0 docs (id/rev)', function (done) {
            var newDocs = [{'testID': docId + "1", 'docNo': "1"},
                {'testID': docId + "2", 'docNo': "2"}];

            bl.getAll(function (err, docs) {
                expect(err).to.be.null;
                expect(docs).not.to.be.null;
                expect(docs.length).to.be.equal(0);

                bl.insertBulk(newDocs, function (err, insertResult) {
                    expect(err).to.be.null;
                    expect(insertResult).to.be.a('array');
                    expect(insertResult).not.to.be.empty;
                    expect(insertResult.length).to.be.equal(newDocs.length);

                    bl.deleteBulk([], function (err, result) {
                        expect(err).to.be.null;
                        expect(result).to.be.true;

                        bl.getAll(function (err, allDocs) {
                            expect(err).to.be.null;
                            expect(allDocs).not.to.be.null;
                            expect(allDocs.length).to.be.equal(allDocs.length);
                            done();
                        });
                    });
                });
            });
        });
    });

    describe('BaseBL.deleteAll', function () {
        it('BaseBL.deleteAll single doc', function (done) {
            var newDocs = [{'testID': docId + "1", 'docNo': "1"}]

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).not.to.be.empty;
                expect(insertResult.length).to.be.equal(newDocs.length);

                bl.deleteAll(function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;

                    bl.getAll(function (err, docs) {
                        expect(err).to.be.null;
                        expect(docs).to.be.a('array');
                        expect(docs).to.be.empty;
                        expect(docs.length).to.be.equal(0);

                        done();
                    });
                });
            });
        });

        it('BaseBL.deleteAll multiple doc', function (done) {
            var newDocs = [{'testID': docId + "1", 'docNo': "1"},
                {'testID': docId + "2", 'docNo': "2"}];

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).not.to.be.empty;
                expect(insertResult.length).to.be.equal(newDocs.length);
                bl.deleteAll(function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;

                    bl.getAll(function (err, docs) {
                        expect(err).to.be.null;
                        expect(docs).to.be.a('array');
                        expect(docs).to.be.empty;
                        expect(docs.length).to.be.equal(0);

                        done();
                    });
                });
            });
        });

        it('BaseBL.deleteAll no docs', function (done) {
            var newDocs = [];

            bl.insertBulk(newDocs, function (err, insertResult) {
                expect(err).to.be.null;
                expect(insertResult).to.be.a('array');
                expect(insertResult).to.be.empty;
                expect(insertResult.length).to.be.equal(newDocs.length);

                bl.deleteAll(function (err, result) {
                    expect(err).to.be.null;
                    expect(result).to.be.true;

                    bl.getAll(function (err, docs) {
                        expect(err).to.be.null;
                        expect(docs).to.be.a('array');
                        expect(docs).to.be.empty;
                        expect(docs.length).to.be.equal(0);

                        done();
                    });
                });
            });
        });
    });

    describe('BaseBL.updateAttributeByID', function () {
        it('BaseBL.updateAttributeByID update existing attribute', function (done) {
            var doc = {testID: docId, attr: '1'}

            // Insert Entity
            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.updateAttributeByID(result.id, "attr", '2', function (err, response) {
                    expect(err).to.be.null;
                    expect(response.id).to.be.equal(result.id);

                    //Check if selected entity matches the inserted entity
                    bl.getByID(result.id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc.testID).to.exist;
                        expect(getDoc.testID).not.to.be.empty;
                        expect(getDoc.testID).to.be.a('string');
                        expect(getDoc.testID).to.be.equal(docId);
                        expect(getDoc.attr).to.exist;
                        expect(getDoc.attr).not.to.be.empty;
                        expect(getDoc.attr).to.be.a('string');
                        expect(getDoc.attr).to.be.equal('2');
                        done();
                    });
                });
            });
        });

        it('BaseBL.updateAttributeByID update new attribute', function (done) {
            var doc = {testID: docId}

            // Insert Entity
            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.updateAttributeByID(result.id, "attr", '2', function (err, response) {
                    expect(err).to.be.null;
                    expect(response.id).to.be.equal(result.id);

                    //Check if selected entity matches the inserted entity
                    bl.getByID(result.id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc.testID).to.exist;
                        expect(getDoc.testID).not.to.be.empty;
                        expect(getDoc.testID).to.be.a('string');
                        expect(getDoc.testID).to.be.equal(docId);
                        expect(getDoc.attr).to.exist;
                        expect(getDoc.attr).not.to.be.empty;
                        expect(getDoc.attr).to.be.a('string');
                        expect(getDoc.attr).to.be.equal('2');
                        done();
                    });
                });
            });
        });

        it('BaseBL.updateAttributeByID update existing attribute, same value', function (done) {
            var doc = {testID: docId, attr: '1'}

            // Insert Entity
            bl.insert(doc, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.updateAttributeByID(result.id, "attr", '1', function (err, response) {
                    expect(err).to.be.null;
                    expect(response).to.be.false;
                    expect(response.id).not.to.be.exist;

                    //Check if selected entity matches the inserted entity
                    bl.getByID(result.id, function (err, getDoc) {
                        expect(err).to.be.null;
                        expect(getDoc.testID).to.exist;
                        expect(getDoc.testID).not.to.be.empty;
                        expect(getDoc.testID).to.be.a('string');
                        expect(getDoc.testID).to.be.equal(docId);
                        expect(getDoc.attr).to.exist;
                        expect(getDoc.attr).not.to.be.empty;
                        expect(getDoc.attr).to.be.a('string');
                        expect(getDoc.attr).to.be.equal('1');
                        done();
                    });
                });
            });
        });

        it('BaseBL.updateAttributeByID update non valid id', function (done) {

            bl.updateAttributeByID("asdf", "attr", '1', function (err, response) {
                expect(err).not.to.be.null;
                done();
            });
        });

        it('BaseBL.updateAttributeByID id is missing', function (done) {

            bl.updateAttributeByID(undefined, "attr", '1', function (err, response) {
                expect(err).not.to.be.null;
                expect(err).to.be.equal('ID is undefined')
                done();
            });
        });

        it('BaseBL.updateAttributeByID attribute name is missing', function (done) {

            bl.updateAttributeByID("asdf", undefined, '1', function (err, response) {
                expect(err).not.to.be.null;
                expect(err).to.be.equal('Attribute Name is undefined')
                done();
            });
        });

    });

    describe('BaseBL.getByView', function () {

        it('BaseBL.getByView design and view name exists', function (done) {

            var view = testTools.getViewWithDocID(docId);

            bl.insert(view, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByView(undefined, docId, "testIDView", true, function (err, viewResults) {
                    expect(err).to.be.null;
                    expect(viewResults).not.to.be.null;
                    expect(viewResults).to.be.a('array');
                    expect(viewResults).to.be.empty;

                    done();
                });
            });
        });

        it('BaseBL.getByView view name does not exist', function (done) {


            var view = testTools.getViewWithDocID(docId);

            // Insert Entity
            bl.insert(view, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByView(undefined, docId, "testIDView1", true, function (err, viewResults) {
                    expect(err).not.to.be.null;
                    expect(viewResults).to.be.null;

                    done();
                });
            });
        });

        it('BaseBL.getByView design name does not exist', function (done) {

            var view = testTools.getViewWithDocID(docId);

            // Insert Entity
            bl.insert(view, function (err, result) {
                expect(err).to.be.null;
                expect(result.id).to.exist;
                expect(result.id).not.to.be.empty;
                expect(result.id).to.be.a('string');

                bl.getByView(undefined, docId + "1", "testIDView", true, function (err, viewResults) {
                    expect(err).not.to.be.null;
                    expect(viewResults).to.be.null;

                    done();
                });
            });
        });

        it('BaseBL.getByView single key single entry', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(1);

                        var receivedDoc = viewResults[0];
                        expect(receivedDoc).not.to.be.null;
                        expect(receivedDoc.testID).to.exist;
                        expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView single key no entries', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView(docs[0].testID + "asdf", docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView single key multiple entries', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc1", testno: "2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(2);

                        var calls = [];

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[0].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[0].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[0].testno);

                            asyncCallback(null, true);
                        });

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[1].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[1].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[1].testno);

                            asyncCallback(null, true);
                        });


                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

        it('BaseBL.getByView array, single key single entry', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(1);

                        var receivedDoc = viewResults[0];
                        expect(receivedDoc).not.to.be.null;
                        expect(receivedDoc.testID).to.exist;
                        expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView array, single key no entries', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID + "asdf"], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView array, single key multiple entries', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc1", testno: "2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(2);

                        var calls = [];

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[0].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[0].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[0].testno);

                            asyncCallback(null, true);
                        });

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[1].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[1].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[1].testno);

                            asyncCallback(null, true);
                        });


                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

        it('BaseBL.getByView array, multiple keys single entry', function (done) {


            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID, "asdf"], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(1);

                        var receivedDoc = viewResults[0];
                        expect(receivedDoc).not.to.be.null;
                        expect(receivedDoc.testID).to.exist;
                        expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView array, multiple keys no entries', function (done) {


            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID + "asdf", "asdf"], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults).to.be.empty;

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView array, multiple keys multiple entries', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1", testno: "1"}, {testID: docId + "doc2", testno: "2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                // Insert Entity
                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView([docs[0].testID, docs[1].testID], docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(2);

                        var calls = [];

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[0].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[0].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[0].testno);

                            asyncCallback(null, true);
                        });

                        calls.push(function (asyncCallback) {

                            var doc = docs.find(function findElement(element) {
                                return element.testno === docs[1].testno;
                            });

                            expect(doc).not.to.be.undefined;

                            expect(doc.testID).to.exist;
                            expect(doc.testID).not.to.be.empty;
                            expect(doc.testID).to.be.a('string');
                            expect(doc.testID).to.be.equal(docs[1].testID);
                            expect(doc.testno).to.exist;
                            expect(doc.testno).not.to.be.empty;
                            expect(doc.testno).to.be.a('string');
                            expect(doc.testno).to.be.equal(docs[1].testno);

                            asyncCallback(null, true);
                        });


                        async.parallel(calls, function (err, result) {
                            expect(err).to.be.null;
                            done();
                        });
                    });
                });
            });
        });

        it('BaseBL.getByView include docs', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView(docs[0].testID, docId, "testIDView", true, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(1);

                        var receivedDoc = viewResults[0];
                        expect(receivedDoc).not.to.be.null;
                        expect(receivedDoc.testID).to.exist;
                        expect(receivedDoc.testID).to.be.equal(docs[0].testID);

                        done();
                    });
                });
            });
        });

        it('BaseBL.getByView dont include doc', function (done) {

            var view = testTools.getViewWithDocID(docId);
            var docs = [{testID: docId + "doc1"}, {testID: docId + "doc2"}];

            bl.insertBulk(docs, function (err, result) {
                expect(err).to.be.null;
                expect(result).to.be.a('array');
                expect(result).not.to.be.empty;
                expect(result.length).to.be.equal(docs.length);

                bl.insert(view, function (err, result) {
                    expect(err).to.be.null;
                    expect(result.id).to.exist;
                    expect(result.id).not.to.be.empty;
                    expect(result.id).to.be.a('string');

                    bl.getByView(docs[0].testID, docId, "testIDView", false, function (err, viewResults) {
                        expect(err).to.be.null;
                        expect(viewResults).not.to.be.null;
                        expect(viewResults).to.be.a('array');
                        expect(viewResults.length).to.be.equal(1);

                        var receivedDoc = viewResults[0];
                        expect(receivedDoc.id).not.to.be.null;
                        expect(receivedDoc.key).not.to.be.null;
                        expect(receivedDoc.value).not.to.be.null;
                        expect(receivedDoc.key).to.be.equal(docs[0].testID);

                        done();
                    });
                });
            });
        });
    });
})
;

