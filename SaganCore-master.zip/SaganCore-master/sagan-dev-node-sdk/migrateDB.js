/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var dbNameFrom = "hazardevents"; // Insert old DB name (as in the cloudant itself)
var entityNameTo = "hazard"; // Insert the new ENTITY NAME (hazard, user, shield etc...)



var dbmgr = require('./cloudant-dal/db-manager.js');
var db = require('./cloudant-dal/base.dal.js');
var dal = new db(dbNameFrom);
var bl = require('./bl.js')[entityNameTo];

console.log("Migrating from db name '" + dbNameFrom + "' to '" + bl.dal._dbName + "'");
dal.list(function (err, docs) {
    if (err) {
        console.log("error getting all the docs from the old DB. reason - " + err);
    } else {
        console.log("Fetched docs from old DB. total of - " + docs.length);

        bl.dal.doesDBExist(function (err, result) {
            if (err) {
                console.log("Error checking if DB exists. reason - " + err);
            } else {
                if (!result) {
                    console.log("Target db doesn't exist. creating it now");
                    dbmgr.create(entityNameTo, function (err, createResult) {
                        if (err) {
                            console.log("error creating the new DB. reason - " + err);
                        } else {
                            console.log("New db created successfully");
                            fillWithData(docs);
                        }
                    });
                } else {
                    fillWithData(docs);
                }
            }
        })
    }
});

var fillWithData = function (docs) {
    console.log("Populating data now with " + docs.length + " docs");
    console.log("DOCS: " + JSON.stringify(docs));

    docs.forEach(function(doc) {
        delete doc._id;
        delete doc._rev;
    });

    bl.insertBulk(docs, function (err, result) {
        if (err) {
            console.log("error getting all the docs from the old DB. reason - " + err);
        } else {
            console.log("DOCS: " + JSON.stringify(result));
            console.log("Populating succeeded.");
            console.log("END!");
        }
    });
};
