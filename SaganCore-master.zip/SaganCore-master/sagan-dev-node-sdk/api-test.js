/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/

var framework = require('./index.js');
var wfapi = framework.api;
wfapi.startServer();
