Formatters are text processing tools. They are used to process th etext before intent and entity extraction.
