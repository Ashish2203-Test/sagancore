
[![node](https://img.shields.io/badge/Watson Personal Assistant-0.7-yellowgreen.svg)]() [![node](https://img.shields.io/badge/node-6.10.10-yellow.svg)]() [![NPM](https://img.shields.io/badge/npm-3.10.10-yellow.svg)]() [![Build Status](https://travis.ibm.com/ConsumerIoT/SaganCore.svg?token=eBM4ULW7rxEZxaXtxYQp&branch=master)](https://travis.ibm.com/ConsumerIoT/SaganCore) [![License](https://img.shields.io/badge/license-APACHE2-blue.svg)]()

## DISCLAIMER

THIS IS INITIAL VERSION OF THE Watson Assistant. NOT EVERYTHING IS SUPPORTED AND NOT EVERYTHING IS DEBUGGED.
IF SOMETHING IS NOT WORKING, YOU CAN EITHER FIX IT AND SEND A PULL REQUEST OR YOU CAN ASK REPORT AN ISSUE TO THE Watson Assistant TEAM.


## Table of Contents
* [Video Tutorials](#videos)
* [SkillSets](#what-is-a-skillSet)
* [Watson Assistant API](#watson-personal-assistant-api)
* [Skill](#skill)
* [Registering Your Skill](#registering-your-skill)
* [Accessing Logs](#logs)
* [Conversing With WA](#conversing-with-wpa)
* [API Documentation](#swagger)
* [Maintainers](#maintainers)

___

## [Videos](https://ibm.box.com/s/t356n8e7g8yk4lp3ls35yp6za3l77pvs)

Some simple videos which shows how to use the Watson Assistant

## What Is a SkillSet

SkillSet is a virtual instance which combines set of skills and is responsible
to find the best skill in his set that can respond to a user request.
If skill name is not specified, the skillSet will find the best skill to
respond based on decision algorithm which is based on context, confidence and
more.
The Watson Assistant hosts skillSets and enabled the applications to send user request
to a skillSet using the REST API. The application should create a skillSet, add skill
and bind them to skillSets before starting conversation with it.

## Watson Assistant API

The Watson Assistant supports the following groups of API's:

Group | Description
--- | ---
SkillSets | SkillSet CRUD
Converse | Conversation with skills and skillSets
Skills | skill CRUD and maintenance
Health | health check of skills and skillSets
SkillSets-Skills Links | CRUD for SkillSet - skill linking

## SkillSets

Method | API | Description
--- | --- | ---
GET | /skillSets | Get all created skillSets
POST | /skillSets | Create new skillSet
DELETE | /skillSets/{skillSetName} | Delete and remove a skillSet
GET | /skillSets/{skillSetName} | Returns skillSet data
PUT | /skillSets/{skillSetName} | Update skillSet's skills list

## Converse

Method | API | Description
--- | --- | ---
POST | /converse | Converse with all available skills
POST | /skillSets/{skillSetName}/converse | Converse with specified skillSet
POST | /skills/{skillName}/converse | Converse with specified skill

## Skills

Method | API | Description
--- | --- | ---
GET | /skills | Get all created skills
POST | /skills | Create new skill
DELETE | /skills/{skillName} | Delete a skill
GET | /skills/{skillName} | Returns skill data
PUT | /skillSets/{skillName} | Update skill's data
GET | /skills/{skillName}/version | Returns skill's version
PUT | /skills/{skillName}/refresh | Update the skill's manifest and intents from the skill's server

## Health

Method | API | Description
--- | --- | ---
GET | /skills/{skillName}/health | skill health check
GET | /skillSets/{skillSetName}/health | skillSet health check

## SkillSets-Skills Links

Method | API | Description
--- | --- | ---
GET | /skills/{skillName}/skillSets | Return all skillSets which a specific skill is attached to
POST | /skills/{skillName}/skillSets | Attach specific skill to multiple skillSets
DELETE | /skillSets/{skillSetName}/links/{skillName} | Unbind a skill from a skillSet
GET | /skillSets/{skillSetName}/links/{skillName} | Get the attachment details between specific skillSet and skill
PUT | /skillSets/{skillSetName}/links/{skillName} | Update the attachment details between a skillSet and a skill

## skills

The skills api is used as the place to register skills that can be used by the component. skillSets can only bind skills which are registered, and the component can converse only skills which are registered.
If a skill is deleted from the registry, the skill will also be removed from all skillSets which uses it.

For information how to build a skill please refer to the Boilerplate documentation / example.

### What you will needed

- Git client for cloning project from GitHub

- Node.js version 6.10.0 or later (Node.js distributions typically install a matching version of npm)

- For deploying to Bluemix
  - Bluemix account (register for your free trial account or log in to Bluemix if you already have an account).
  - The Cloud Foundry command-line interface (CLI)

### How To Deploy Conversation Component To Bluemix

It is only possible to deploy the conversation component using through the [Sagan Hub](https://github.ibm.com/ConsumerIoT/SaganHub#deploying-a-new-core)

### How To Install a Local Server

Since the component uses Cloudant Database to load and save its configuration it first need to be deployed to Bluemix.

- Clone the Watson AssistantCore from GitHub ```git clone https://github.ibm.com/ConsumerIoT/SaganCore```

- Change to core folder ```cd SaganCore```

- Run ```npm install```

- Login to the correct environment in Bluemix with  ```cf login```

- Change the file package.json according to your deployed core.
    In the ```scripts``` section, change the script ```dev-local``` and set the env var ```WF_DEPLOY_DIRECT_TARGET_PREFIX=``` to the name of your deployed instance in Bluemix.
    
- Start the Conversation Component by running ```npm run dev-local```

- Using the Swagger page, follow the following instructions to create your first skillSet. **Note!** You should have instance of skill, implementing the new contract running on cloud to be able to complete the next steps

  - Add new skill
  - Create new skillSet
  - Bind skill to skillSet

- Enjoy! converse with the skillSet or skill using the converse API


### Types of skills

#### Primary skill

Skill is a module that can respond to user requests or system events. When Watson Assistant sends a **request** to a skill, the skill should do its best to answer the request. The data the skill sends back to the component is what we call a **response**.
The Watson Assistant, first "asks" all primary skills if they can answer the request before it "ask" one of them to respond. This is the main difference between primary skill and all other skills types (as defined by the component). That means a skill can keep a state knowing it will be called only if the request is for it (which otherwise might have changed its state).

Writing a skill can be difficult as there are few steps and contract that you as a skill developer should follow. Luckily, IBM engineers have developed skill Boilerplate which uses skill SDK that simplifies development and makes it easy to write your first cognitive assistant. The skill Boilerplate can be found in Github:

```

https://github.ibm.com/ConsumerIoT/ExpertiseBoilerPlateRemote
```

Clone it and start writing your first skill. Enjoy! (and don't forget to publish it)

#### Fallback skill

When binding skill to a skillSet, the bound skill can be defined as a fallback skill. Fallback skills are used by the conversation component to respond to a user request when all the other non fallback (primary) skills failed to respond. You can have multiple fallback skills. If more then one fallback skill is bound, the core will select the one with the highest confidence.

**Note!** The selected fallback skill will be requested to respond to the user request even if the core will not use this response. The skill developer should take this into account when developing fallback skill.

### Defaulting to a skill

 To add default response to a skillSet, a fallback skill that catches all should be added and bound to the skillSet. The preferred way to catch all inputs is to use the regexp based skill with the following intent defined in the regex JSON file:

```
{
  "intents" : [
    {
      "name" : ["all"],
      "grammar" : [
        "*"
      ]
    }
  ],

  "entities" : {
  },

  "synonyms" : [
  ]
}

```

### Providing NLU credentials
When registering the skill to the component (with the PUT /skills API) it is important to add the NLU credentials if there are any.
In the JSON a new object field should be added named "nluCredentials".
In it the credentials will be added by their type - if we use Watson conversation service the JSON would like like:

```
{
  "name": "small-talk",
  "nluCredentials" : {
      "wcs" : {
          "version" : "v1",
          "version_date": "2016-09-27",
          "username": "<<username>>",
          "password": "<<password>>"
      }
  },
  "url": "small-talk-skill.mybluemix.net"
}
```


## Logs

#### Accessing Web Logs

All the logs for your Watson Assistant instance can be found by going to...
```
https://watson-personal-assistant-toolkit.mybluemix.net/logs/?api_key=YOUR_API_KEY_HERE
```

#### For WPA Developers

All logs are being saved by default to .../logs folder. The logging level can be defined in the .env file:

```
# [Optional] Logger printouts level (info, verbose, debug, error)
LOGGER_LEVEL=
```

The logs folder can be changed using the .env file in:

```
# [Optional] Logger output file path (default is ./log)
LOGGER_DIR=
```

And there is an option to clear all logs upon starting / restarting the core:

```
# [Optional] Clear log folder on startup (default false)
LOGS_CLEAR=
```

## Conversing With WA

### Request

This defines the request object.

``` json
{
  "text": "string",
  "language": "string",
  "userID": "string",
  "deviceType": "string",
  "additionalInformation": {
    "context": {},
    "session": {
        "id": "string",
        "new": bool
    }
  }
}
```

### Response

``` json
{
  "version": "string",
  "reject": "boolean",
  "shouldEndSession": "boolean",
  "speech": {
    "text": "string",
    "expressiveness": "string"    
  },
  "card": {
    "type": "string",
    "title": "string",
    "subtitle": "string",
    "content": {
    }
  },
  "context": {
    "user": {
    },
    "session": {
    },
    "application": {
    }
  },
  "metrics": {
    "skill": "string"
  }
}
```

## Swagger

Every instance of Watson Assistant has a Swagger API dock. You can access it at...

```
https://watson-personal-assistant-toolkit.mybluemix.net/docs/?api_key=YOUR_API_KEY_HERE
```

**NOTE:** In order to make API calls through the Swagger interface you MUST put your api key in the text box field top right and click **Explore**.


## Maintainers

Dean Haber - [deanh@il.ibm.com](deanh@il.ibm.com)
Jordan Moore - [jtmoore@us.ibm.com](jtmoore@il.ibm.com)
Bryan Kribbs - [bakribbs@us.ibm.com](bakribbs@us.ibm.com)
