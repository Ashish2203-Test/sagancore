/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

'use strict';

const morgan = require('morgan');
const passport = require('passport');
//const logger = require('./logger');
const logger = require('../sagan-logging/logger');
const api = require('sagan-dev-node-sdk').api;
let bl = require('sagan-dev-node-sdk').bl;
let addRequestId = require('express-request-id')();

const app = api.app;

app.use(morgan(process.env.MORGAN_FORMAT || 'short', {
    'stream': {
        write: function (str) {
            logger.silly(null, null, null, null, str.slice(0, -1), null, true);
            
        }
    }
}));

// Handles non-https requests
// We check for process.env.DEBUG_CLIENT_ID for local dev
app.use(function (req, res, next) {
    if (process.env.DEBUG_CLIENT_ID ||
        (req.headers["x-forwarded-proto"] && (req.headers["x-forwarded-proto"].toLowerCase() === "https".toLowerCase()))) {
        next();
    } else {
        res.sendStatus(403);
    }
});

// For local debug
app.use(function (req, res, next) {
    if (process && process.env && process.env.VCAP_APPLICATION) {
        next();
    } else {
        req.headers.clientid = process.env.DEBUG_CLIENT_ID;
        next();
    }
});

app.get('/logs', function (req, res) {

    // https://stackoverflow.com/questions/21934831/nodejs-express-stream-stdout-instantly-to-the-client

    res.writeHead(200, {
        "Content-Type": "text/event-stream",
        "Cache-control": "no-cache"
    });

    // Sends entire history + stream. does it closes the connection when done?
    if (logger.getStream()) {
        logger.getStream().stream().on('log', function (data) {
            res.write("[Log Level: " + data.level.toString() + "] [Timestamp: " + data.timestamp.toString() + "] \nMessage: " + data.message.toString() + "\n\n");
        });            
    }
});

// For localhost, debug only! setting all the env vars
let setDebugVars = function (callback) {
    if (process && process.env && !process.env.VCAP_APPLICATION) {
        if (process.env.DEBUG_API_KEY) {
            bl.route.getRoutingDataByAPIKey(process.env.DEBUG_API_KEY, function (data) {
                logger.info(null, null, null, null, "Tenant route data: " + JSON.stringify(data), null, false);
               
                process.env.DEBUG_CLIENT_ID = data.clientID;
                callback(data.coreUrl);
            });
        } else {
            callback(process.env.WF_DEPLOY_DIRECT_TARGET_PREFIX + ".mybluemix.net");
        }

    } else {
        let uri = JSON.parse(process.env.VCAP_APPLICATION).uris[0];
        callback(uri);
    }
};

setDebugVars(function (coreUrl) {
    api.startServer();
});

module.exports = app; // for testing
