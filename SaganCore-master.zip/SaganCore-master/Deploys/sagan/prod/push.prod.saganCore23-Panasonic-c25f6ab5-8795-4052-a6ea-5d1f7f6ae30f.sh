cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore23-Panasonic-c25f6ab5-8795-4052-a6ea-5d1f7f6ae30f.yml
