cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore5-AndyBarnesAuto-4f90c6a3-c4e7-1922-ed95-85c7946efbad.yml
