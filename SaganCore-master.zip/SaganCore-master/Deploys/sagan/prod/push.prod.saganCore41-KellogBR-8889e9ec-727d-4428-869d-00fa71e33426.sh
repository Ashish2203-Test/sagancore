cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore41-KellogBR-8889e9ec-727d-4428-869d-00fa71e33426.yml
