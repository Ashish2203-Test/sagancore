cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore32-LaPoste-d39248bd-4729-4910-9801-f79411d1bb26.yml
