cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore21-Emma-1d8799a9-aa62-4de0-a71b-ddf378fb0e73.yml
