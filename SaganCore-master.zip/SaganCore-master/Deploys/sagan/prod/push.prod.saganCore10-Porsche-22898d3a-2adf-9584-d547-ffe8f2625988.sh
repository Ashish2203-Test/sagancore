cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore10-Porsche-22898d3a-2adf-9584-d547-ffe8f2625988.yml
