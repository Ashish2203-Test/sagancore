cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore7-LGE-642da4b2-93a0-c6cd-057c-ae2c057e0867.yml
