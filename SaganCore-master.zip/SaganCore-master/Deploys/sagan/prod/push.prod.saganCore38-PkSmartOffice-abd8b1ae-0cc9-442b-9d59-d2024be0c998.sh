cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore38-PkSmartOffice-abd8b1ae-0cc9-442b-9d59-d2024be0c998.yml
