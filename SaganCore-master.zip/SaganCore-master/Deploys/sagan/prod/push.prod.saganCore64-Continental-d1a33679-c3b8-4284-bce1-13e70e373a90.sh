cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore64-Continental-d1a33679-c3b8-4284-bce1-13e70e373a90.yml
