cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore37-GabiZodik-ff42b0a7-c467-4bec-93bd-7741ceca09e4.yml
