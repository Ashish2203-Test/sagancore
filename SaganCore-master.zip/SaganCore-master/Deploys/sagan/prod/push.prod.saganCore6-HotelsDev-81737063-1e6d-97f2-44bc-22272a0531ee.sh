cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore6-HotelsDev-81737063-1e6d-97f2-44bc-22272a0531ee.yml
