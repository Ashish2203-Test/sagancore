cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore27-Caesars1-f5924793-bab0-48c6-9c1c-dd4687136c2a.yml
