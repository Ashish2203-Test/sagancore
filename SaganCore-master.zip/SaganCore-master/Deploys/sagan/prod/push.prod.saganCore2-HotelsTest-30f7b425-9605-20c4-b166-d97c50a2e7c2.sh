cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore2-HotelsTest-30f7b425-9605-20c4-b166-d97c50a2e7c2.yml
