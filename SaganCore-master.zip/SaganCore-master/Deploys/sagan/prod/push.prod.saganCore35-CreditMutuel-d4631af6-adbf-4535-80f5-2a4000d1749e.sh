cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore35-CreditMutuel-d4631af6-adbf-4535-80f5-2a4000d1749e.yml
