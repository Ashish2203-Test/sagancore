cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore36-GabiZodik-a279987a-11bf-4b57-9a83-08e40f45f38c.yml
