cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore32-Telstra-536e24b2-f131-4919-b903-6ab801eeb65d.yml
