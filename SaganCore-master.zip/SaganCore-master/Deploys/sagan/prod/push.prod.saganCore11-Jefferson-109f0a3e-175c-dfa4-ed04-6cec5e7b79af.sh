cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore11-Jefferson-109f0a3e-175c-dfa4-ed04-6cec5e7b79af.yml
