cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore65-Allianz-0634e967-419e-4182-88c7-c2f859df97b5.yml
