cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore8-Zandra-9a3d54c6-ba23-59eb-b15f-a7e7be92854d.yml
