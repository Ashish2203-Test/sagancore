cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore8-Segev-2aef0d0c-3b23-4e41-8b00-2a2a78166b97.yml
