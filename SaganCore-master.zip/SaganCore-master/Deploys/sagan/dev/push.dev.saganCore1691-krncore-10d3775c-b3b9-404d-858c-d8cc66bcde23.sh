cf login -a https://api.ng.bluemix.net -u apikey -p mqYbmu61u769F6Xj-3ipPu09F2JVYmJzp5JZn5_3bSM6 -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f /var/lib/jenkins/workspace/Sagan_Core/Deploys/sagan/dev/dev.saganCore1691-krncore-10d3775c-b3b9-404d-858c-d8cc66bcde23.yml


