cf target -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore2-Dekel-119bd2d2-84ce-2c0c-9bc3-84d607c38af8.yml
