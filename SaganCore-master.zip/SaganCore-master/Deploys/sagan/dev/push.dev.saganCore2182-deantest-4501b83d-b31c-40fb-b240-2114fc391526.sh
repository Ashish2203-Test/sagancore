cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore2182-deantest-4501b83d-b31c-40fb-b240-2114fc391526.yml
