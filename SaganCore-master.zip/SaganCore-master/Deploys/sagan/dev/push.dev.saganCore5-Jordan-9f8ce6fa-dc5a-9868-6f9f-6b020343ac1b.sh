cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore5-Jordan-9f8ce6fa-dc5a-9868-6f9f-6b020343ac1b.yml
