cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore4-Yishai-28f47dc4-eb17-8982-87d0-057a0d6a2e1b.yml
