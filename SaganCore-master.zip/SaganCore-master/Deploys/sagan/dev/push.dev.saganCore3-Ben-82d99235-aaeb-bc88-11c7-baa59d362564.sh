cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore3-Ben-82d99235-aaeb-bc88-11c7-baa59d362564.yml
