cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore12-Chintamani-6c2ee278-a76b-4545-8d05-352d89c7dc15.yml
