cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore11-Nisha-310e083b-f345-4bfe-aa54-42640110a87f.yml
